import AsyncStorage from "@react-native-async-storage/async-storage";

const isNativePlatform = typeof navigator !== "undefined" && navigator.product === "ReactNative";

export type Symptom = { name: string; severity: number };

export type HealthEntry = {
  id: string;
  date: string;
  symptoms: Symptom[];
  mood: number;
  sleepHours: number;
  activityMinutes: number;
  notes: string;
};

export const DEMO_FALLBACK_ENTRY_PREFIX = "demo-fallback-";
export function isDemoFallbackEntry(entry: Pick<HealthEntry, "id">): boolean {
  return entry.id.startsWith(DEMO_FALLBACK_ENTRY_PREFIX);
}
export function createDemoFallbackEntries(referenceDate = todayIso()): HealthEntry[] {
  const base = new Date(`${referenceDate}T12:00:00.000Z`);
  return [0, 1, 2].map((offset) => {
    const date = new Date(base);
    date.setUTCDate(date.getUTCDate() - offset);
    return {
      id: `${DEMO_FALLBACK_ENTRY_PREFIX}${offset}`,
      date: date.toISOString().slice(0, 10),
      symptoms: offset === 1 ? [{ name: "Sample symptom", severity: 2 }] : [],
      mood: 3,
      sleepHours: 7,
      activityMinutes: 20,
      notes: "Sample entry for exploring the journal. This is not your health data.",
    };
  });
}

export type JournalInsight = {
  title: string;
  detail: string;
  tone: "calm" | "attention";
  evidenceDates: string[];
  evidenceCount: number;
};

const STORAGE_KEY = "ai-health-journal.entries.v1";
const PREFERENCES_KEY = "ai-health-journal.preferences.v1";
const PREP_KEY = "ai-health-journal.prep.v1";
const SECURITY_KEY = "ai-health-journal.security.v1";
const BACKUP_KEY = "ai-health-journal.backup.key.v1";
const BACKUP_META_KEY = "ai-health-journal.backup.meta.v1";
const BACKUP_STATUS_KEY = "ai-health-journal.backup.status.v1";
const DRAFT_HISTORY_KEY = "ai-health-journal.prep.drafts.v1";
const DRAFT_META_KEY = "ai-health-journal.prep.draft-meta.v1";
const ANALYTICS_CONTEXT_KEY = "ai-health-journal.analytics.context.v1";
const RETENTION_KEY = "ai-health-journal.retention.v1";
const NOTICE_TIMING_KEY = "ai-health-journal.notice-timing.v1";
const CHECKLIST_KEY = "ai-health-journal.prep.checklist.v1";
const CHECKLIST_LABEL_KEY = "ai-health-journal.prep.checklist-label.v1";
const ACTIVITY_KEY = "ai-health-journal.activity.v1";
const IMPORT_UNDO_KEY = "ai-health-journal.import-undo.v1";
export const ONBOARDING_KEY = "ai-health-journal.onboarding.v1";

export type JournalPreferences = { focus: "sleep" | "mood" | "symptoms"; cadence: "daily" | "weekly" | "on-demand"; promptStyle: "concise" | "reflective" | "questions"; questionStyle: "concise" | "exploratory" | "structured" };
export type ClinicianContext = { onset: string; duration: string; triggers: string; impact: string };
export type ClinicianReportFields = { mood: boolean; sleep: boolean; activity: boolean; symptoms: boolean; noteStatus: boolean; questions: boolean; context: boolean };
export type ClinicianReportMode = "detailed" | "concise";
export type PrepPreferences = { rangeDays: 7 | 14 | 30; questions: string[]; context: ClinicianContext };
export type SecurityPreferences = { biometricLock: boolean; lockTimeoutSeconds: 0 | 60 | 300 | 900 };
export type BackupStatus = { savedAt: string | null; restoredAt: string | null };
export type AnalyticsContextAnnotation = { date: string; note: string };
export type RetentionPreference = { appointmentReminder: boolean; dismissed: boolean; appointmentDate: string | null };
export type NoticeTiming = 6000 | 12000 | "persistent";
export type LocalActivityEvent = { id: string; type: "journal_saved" | "backup_saved" | "backup_restored" | "import_completed" | "import_undone" | "import_undo_expired"; occurredAt: string; detail?: string };

export const defaultPreferences: JournalPreferences = { focus: "symptoms", cadence: "daily", promptStyle: "reflective", questionStyle: "structured" };
export const defaultSecurityPreferences: SecurityPreferences = { biometricLock: false, lockTimeoutSeconds: 300 };
export const defaultBackupStatus: BackupStatus = { savedAt: null, restoredAt: null };
export const defaultRetentionPreference: RetentionPreference = { appointmentReminder: false, dismissed: false, appointmentDate: null };
export const defaultNoticeTiming: NoticeTiming = 6000;
export const defaultClinicianContext: ClinicianContext = { onset: "", duration: "", triggers: "", impact: "" };
export const defaultClinicianReportFields: ClinicianReportFields = { mood: true, sleep: true, activity: true, symptoms: true, noteStatus: true, questions: true, context: true };

export function serializeLocalValue(value: unknown): string {
  try {
    const serialized = JSON.stringify(value);
    if (typeof serialized !== "string") throw new Error("Local data could not be serialized");
    return serialized;
  } catch {
    throw new Error("Local data could not be serialized");
  }
}

export function normalizeNoticeTiming(value: unknown): NoticeTiming {
  return value === 12000 || value === "persistent" || value === 6000 ? value : defaultNoticeTiming;
}

export function canChangeNoticeTiming(current: NoticeTiming, next: NoticeTiming, busy: boolean): boolean {
  return !busy && current !== next;
}

export const NOTICE_TIMING_SUCCESS_FEEDBACK_MS = 4000;
export const HYDRATION_TIMEOUT_MS = 10000;

export const HYDRATION_TIMEOUT_MESSAGE = "Local journal loading timed out";
export const HYDRATION_MAX_ATTEMPTS = 3;

function channelLuminance(channel: number): number {
  const normalized = channel / 255;
  return normalized <= 0.03928 ? normalized / 12.92 : Math.pow((normalized + 0.055) / 1.055, 2.4);
}

export function contrastRatio(foreground: string, background: string): number {
  const parse = (hex: string) => {
    const normalized = hex.replace("#", "");
    const value = normalized.length === 3 ? normalized.split("").map((part) => part + part).join("") : normalized;
    return [0, 2, 4].map((offset) => Number.parseInt(value.slice(offset, offset + 2), 16));
  };
  const luminance = (hex: string) => {
    const [red, green, blue] = parse(hex);
    return 0.2126 * channelLuminance(red) + 0.7152 * channelLuminance(green) + 0.0722 * channelLuminance(blue);
  };
  const first = luminance(foreground);
  const second = luminance(background);
  const lighter = Math.max(first, second);
  const darker = Math.min(first, second);
  return (lighter + 0.05) / (darker + 0.05);
}

export function retryProgressAccessibilityLayout() {
  return { maxWidth: "100%" as const, flexShrink: 1, flexWrap: "wrap" as const, minHeight: 34, borderWidth: 2, lineHeight: 18 };
}

function safeHydrationAttempt(currentAttempt: number): number {
  return Number.isFinite(currentAttempt) ? Math.max(0, currentAttempt) : 0;
}

export function nextHydrationAttempt(currentAttempt: number): number {
  return Math.min(safeHydrationAttempt(currentAttempt) + 1, HYDRATION_MAX_ATTEMPTS);
}

export function canRetryHydrationAttempt(currentAttempt: number): boolean {
  return safeHydrationAttempt(currentAttempt) < HYDRATION_MAX_ATTEMPTS;
}

export const ACCESSIBILITY_HEADING_ROLE = "header" as const;
export type NoticeLiveRegion = "polite" | "assertive";
export type ClearConfirmationOutcome = "cancelled" | "cleared" | "failed";
export function clearConfirmationAccessibilityLabel(entryCount: number): string {
  return entryCount > 0 ? `Clear ${entryCount} saved journal entries` : "Clear saved journal data";
}
export function clearConfirmationFocusTarget(outcome: ClearConfirmationOutcome): "settings" {
  void outcome;
  return "settings";
}
export type DeleteEntryOutcome = "deleted" | "failed";
export function deleteEntryFocusTarget(entryId: string, outcome: DeleteEntryOutcome): string | null {
  if (!entryId.trim()) return null;
  return outcome === "failed" ? `detail:${entryId}` : null;
}
export type ImportUndoOutcome = "expired" | "undone" | "failed";
export function importUndoFocusTarget(outcome: ImportUndoOutcome): "import-undo" | null {
  return outcome === "expired" || outcome === "failed" ? "import-undo" : null;
}
export type SettingsOperationOutcome = "backup-failed" | "backup-completed" | "restore-failed" | "restore-completed";
export function settingsOperationFocusTarget(outcome: SettingsOperationOutcome): "settings" {
  void outcome;
  return "settings";
}
export type RetryOperation = "backup" | "restore";
export function retryFocusTargetFor(operation: RetryOperation): "backup-retry" | "restore-retry" {
  return operation === "backup" ? "backup-retry" : "restore-retry";
}

type RetryInput = { attempt: number; max: number };
function normalizeRetryInput(attempt: number, max: number): RetryInput {
  const safeMax = Number.isFinite(max) && max >= 1 ? Math.floor(max) : 3;
  const safeAttemptInput = Number.isFinite(attempt) ? Math.floor(attempt) : 1;
  return { attempt: Math.max(1, Math.min(safeAttemptInput, safeMax)), max: safeMax };
}

export function retryAttemptProgress(progressCopy: string, attempt: number, max = 3): string {
  const safe = normalizeRetryInput(attempt, max);
  return progressCopy.replace("{attempt}", String(safe.attempt)).replace("{max}", String(safe.max));
}
export function retryCapReached(attempt: number, max = 3): boolean {
  const safe = normalizeRetryInput(attempt, max);
  return safe.attempt >= safe.max;
}
export type BackupStatusReview = "backup-recorded" | "backup-missing" | "restore-recorded" | "restore-missing";
export function backupStatusReview(status: BackupStatus, operation: RetryOperation): BackupStatusReview {
  if (operation === "backup") return status.savedAt ? "backup-recorded" : "backup-missing";
  return status.restoredAt ? "restore-recorded" : "restore-missing";
}
export function noticeLiveRegionFor(persistent: boolean): NoticeLiveRegion {
  return persistent ? "assertive" : "polite";
}
export type ModalFocusTransition = "open" | "close" | "unchanged";
export function shouldApplyModalFocusRequest(requestId: number, currentRequestId: number, transition: ModalFocusTransition): boolean {
  return transition === "close" && requestId === currentRequestId;
}
export function resolveModalFocusTargetId(lastTriggerId: string | null, availableTargetIds: readonly string[]): string | null {
  return lastTriggerId && availableTargetIds.includes(lastTriggerId) ? lastTriggerId : null;
}
export function modalFocusTransition(wasOpen: boolean, isOpen: boolean): ModalFocusTransition {
  if (!wasOpen && isOpen) return "open";
  if (wasOpen && !isOpen) return "close";
  return "unchanged";
}
export type HydrationRecoveryFocusTarget = "title" | "progress" | "body" | "retry";

export type HydrationRecoveryViewModel = {
  titleKey: "journalLoadTimeoutTitle" | "journalLoadFailed";
  bodyKey: "journalLoadTimeout" | "journalRecoveryBody";
  retryKey: "retryLoading" | "retryLoadingProgress";
  retrying: boolean;
  titleAccessibilityRole: typeof ACCESSIBILITY_HEADING_ROLE;
  focusOrder: readonly HydrationRecoveryFocusTarget[];
};

export function hydrationRecoveryViewModel(timedOut: boolean, retrying: boolean): HydrationRecoveryViewModel {
  return {
    titleKey: timedOut ? "journalLoadTimeoutTitle" : "journalLoadFailed",
    bodyKey: timedOut ? "journalLoadTimeout" : "journalRecoveryBody",
    retryKey: retrying ? "retryLoadingProgress" : "retryLoading",
    retrying,
    titleAccessibilityRole: ACCESSIBILITY_HEADING_ROLE,
    focusOrder: ["title", "progress", "body", "retry"],
  };
}

export type HydrationRetryTransition = {
  accepted: boolean;
  nextBusyAction: string | null;
};

export function claimHydrationRetry(busyAction: string | null): HydrationRetryTransition {
  if (busyAction === "hydrate") return { accepted: false, nextBusyAction: busyAction };
  return { accepted: true, nextBusyAction: "hydrate" };
}

export function canStartHydrationRetry(busyAction: string | null): boolean {
  return claimHydrationRetry(busyAction).accepted;
}

export function isHydrationTimeoutError(error: unknown): boolean {
  return error instanceof Error && error.message === HYDRATION_TIMEOUT_MESSAGE;
}

export function withTimeout<T>(promise: Promise<T>, timeoutMs: number, message: string, signal?: AbortSignal): Promise<T> {
  const safeTimeoutMs = Number.isFinite(timeoutMs) ? Math.max(0, timeoutMs) : 0;
  return new Promise<T>((resolve, reject) => {
    let settled = false;
    let timer: ReturnType<typeof setTimeout>;
    const cleanup = () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
    };
    const onAbort = () => {
      if (settled) return;
      settled = true;
      cleanup();
      const error = new Error("Operation cancelled");
      error.name = "AbortError";
      reject(error);
    };
    timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new Error(message));
    }, safeTimeoutMs);
    signal?.addEventListener("abort", onAbort, { once: true });
    promise.then((value) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(value);
    }, (error) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(error);
    });
    if (signal?.aborted) onAbort();
  });
}

export function noticeTimingCopyKeyFor(timing: NoticeTiming): "sixSeconds" | "twelveSeconds" | "persistent" {
  return timing === 6000 ? "sixSeconds" : timing === 12000 ? "twelveSeconds" : "persistent";
}

export type NoticePreviewState = { visible: boolean; dismissed: boolean };
export type NoticePreviewAction = "open" | "dismiss" | "auto_clear";

export function reduceNoticePreviewState(state: NoticePreviewState, action: NoticePreviewAction): NoticePreviewState {
  if (action === "open") return { visible: true, dismissed: false };
  if (action === "dismiss") return { visible: false, dismissed: true };
  return { visible: false, dismissed: state.dismissed };
}

export function scheduleRoutineNoticeClear(timing: NoticeTiming, onClear: () => void): ReturnType<typeof setTimeout> | null {
  if (timing === "persistent") return null;
  return setTimeout(onClear, timing);
}

export function scheduleNoticeTimingSuccessClear(onClear: () => void): ReturnType<typeof setTimeout> {
  return setTimeout(onClear, NOTICE_TIMING_SUCCESS_FEEDBACK_MS);
}

export function canRetryNoticeTimingHydration(retrying: boolean, busy: boolean): boolean {
  return !retrying && !busy;
}

export type NoticeTimingLoadResult = { value: NoticeTiming; recovered: boolean };

export async function loadNoticeTimingWithStatus(): Promise<NoticeTimingLoadResult> {
  try {
    const raw = await AsyncStorage.getItem(NOTICE_TIMING_KEY);
    if (!raw) return { value: defaultNoticeTiming, recovered: false };
    const parsed = JSON.parse(raw);
    const value = normalizeNoticeTiming(parsed);
    return { value, recovered: value === defaultNoticeTiming && parsed !== defaultNoticeTiming }; 
  } catch {
    return { value: defaultNoticeTiming, recovered: true };
  }
}

export async function loadNoticeTiming(): Promise<NoticeTiming> {
  return (await loadNoticeTimingWithStatus()).value;
}

export async function saveNoticeTiming(value: NoticeTiming) {
  await AsyncStorage.setItem(NOTICE_TIMING_KEY, serializeLocalValue(normalizeNoticeTiming(value)));
}

export function normalizeHealthEntries(value: unknown): HealthEntry[] {
  const source = Array.isArray(value) ? value : value && typeof value === "object" && Array.isArray((value as { entries?: unknown }).entries) ? (value as { entries: unknown[] }).entries : [];
  const seenIds = new Set<string>();
  const seenDates = new Set<string>();
  return source.flatMap((item) => {
    if (!item || typeof item !== "object") return [];
    const candidate = item as Partial<HealthEntry>;
    if (typeof candidate.id !== "string" || typeof candidate.date !== "string" || !isValidIsoDate(candidate.date)) return [];
    const id = candidate.id.trim().slice(0, 120);
    if (!id || seenIds.has(id) || seenDates.has(candidate.date)) return [];
    seenIds.add(id); seenDates.add(candidate.date);
    const symptoms = Array.isArray(candidate.symptoms) ? candidate.symptoms.flatMap((symptom) => {
      if (!symptom || typeof symptom !== "object") return [];
      const normalized = symptom as Partial<Symptom>;
      const severity = typeof normalized.severity === "number" && Number.isFinite(normalized.severity) ? Math.max(0, Math.min(5, normalized.severity)) : null;
      const name = typeof normalized.name === "string" ? normalized.name.trim().slice(0, 80) : "";
      return name && severity !== null ? [{ name, severity }] : [];
    }) : [];
    const mood = typeof candidate.mood === "number" && Number.isFinite(candidate.mood) ? Math.max(1, Math.min(5, candidate.mood)) : 3;
    const sleepHours = typeof candidate.sleepHours === "number" && Number.isFinite(candidate.sleepHours) ? Math.max(0, Math.min(24, candidate.sleepHours)) : 0;
    const activityMinutes = typeof candidate.activityMinutes === "number" && Number.isFinite(candidate.activityMinutes) ? Math.max(0, Math.min(1440, candidate.activityMinutes)) : 0;
    const notes = typeof candidate.notes === "string" ? candidate.notes.trim().slice(0, 2000) : "";
    return [{ id, date: candidate.date, symptoms, mood, sleepHours, activityMinutes, notes }];
  });
}

export function normalizeLocalActivity(value: unknown): LocalActivityEvent[] {
  if (!Array.isArray(value)) return [];
  const seenIds = new Set<string>();
  const events = value.flatMap((item) => {
    if (!item || typeof item !== "object") return [];
    const candidate = item as Partial<LocalActivityEvent>;
    if (typeof candidate.id !== "string" || typeof candidate.occurredAt !== "string" || !Number.isFinite(Date.parse(candidate.occurredAt))) return [];
    const id = candidate.id.trim().slice(0, 120);
    if (!id || seenIds.has(id)) return [];
    if (candidate.type !== "journal_saved" && candidate.type !== "backup_saved" && candidate.type !== "backup_restored" && candidate.type !== "import_completed" && candidate.type !== "import_undone" && candidate.type !== "import_undo_expired") return [];
    seenIds.add(id);
    const detail = typeof candidate.detail === "string" ? candidate.detail.trim().slice(0, 160) : undefined;
    return [{ id, type: candidate.type, occurredAt: candidate.occurredAt, detail: detail || undefined }];
  });
  return events.sort((a, b) => b.occurredAt.localeCompare(a.occurredAt)).slice(0, 20);
}

export function appendLocalActivity(events: LocalActivityEvent[], event: LocalActivityEvent): LocalActivityEvent[] {
  return normalizeLocalActivity([event, ...events]);
}

export async function loadLocalActivity(): Promise<LocalActivityEvent[]> {
  try {
    const raw = await AsyncStorage.getItem(ACTIVITY_KEY);
    return raw ? normalizeLocalActivity(JSON.parse(raw)) : [];
  } catch { return []; }
}

export async function saveLocalActivity(events: LocalActivityEvent[]) {
  await AsyncStorage.setItem(ACTIVITY_KEY, serializeLocalValue(normalizeLocalActivity(events)));
}

export function isValidIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

export function daysUntilIsoDate(target: string, reference = todayIso()): number | null {
  if (!isValidIsoDate(target) || !isValidIsoDate(reference)) return null;
  const targetMs = Date.parse(`${target}T00:00:00Z`);
  const referenceMs = Date.parse(`${reference}T00:00:00Z`);
  return Math.round((targetMs - referenceMs) / 86400000);
}

export function normalizeRetentionPreference(value: unknown): RetentionPreference {
  if (!value || typeof value !== "object") return defaultRetentionPreference;
  const candidate = value as Partial<RetentionPreference>;
  const appointmentDate = typeof candidate.appointmentDate === "string" && isValidIsoDate(candidate.appointmentDate) ? candidate.appointmentDate : null;
  return { appointmentReminder: candidate.appointmentReminder === true, dismissed: candidate.dismissed === true, appointmentDate };
}

export function normalizeAnalyticsContextAnnotations(value: unknown): AnalyticsContextAnnotation[] {
  if (!Array.isArray(value)) return [];
  const byDate = new Map<string, AnalyticsContextAnnotation>();
  for (const item of value) {
    const candidate = item as Partial<AnalyticsContextAnnotation>;
    if (typeof candidate.date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(candidate.date) || typeof candidate.note !== "string") continue;
    const note = candidate.note.trim().slice(0, 240);
    if (note) byDate.set(candidate.date, { date: candidate.date, note });
  }
  return [...byDate.values()].sort((a, b) => a.date.localeCompare(b.date)).slice(-365);
}

export type UserSafeErrorKind = "backup-missing" | "device-security" | "invalid-data" | "unknown";

export function userSafeErrorKind(error: unknown): UserSafeErrorKind {
  const message = error instanceof Error ? error.message : typeof error === "string" ? error : "";
  if (/No encrypted backup found/i.test(message)) return "backup-missing";
  if (/native device|Biometric|fingerprint|Face ID|Touch ID/i.test(message)) return "device-security";
  if (/Invalid|Unsupported|Incomplete|malformed/i.test(message)) return "invalid-data";
  return "unknown";
}

export function userSafeErrorMessage(error: unknown, fallback = "Something went wrong. Your local data was not changed.") {
  switch (userSafeErrorKind(error)) {
    case "backup-missing": return "No encrypted backup is available on this device.";
    case "device-security": return "Device security could not be completed. Try again or use another available lock method.";
    case "invalid-data": return "The provided data could not be used. Check the format and try again.";
    default: return fallback;
  }
}

export function biometricFailureMessage(errorCode?: string) {
  switch (errorCode) {
    case "user_cancel":
    case "app_cancel":
    case "system_cancel":
      return "Authentication was cancelled. Your journal remains locked.";
    case "not_available":
      return "Biometric authentication is unavailable on this device. Your journal remains locked.";
    case "not_enrolled":
    case "passcode_not_set":
      return "Set up Face ID, Touch ID, or fingerprint in device settings before using journal lock.";
    case "lockout":
      return "Biometric authentication is temporarily locked. Try again after unlocking your device.";
    default:
      return "Biometric authentication did not complete. Your journal remains locked.";
  }
}

export function normalizeBackupStatus(value: unknown): BackupStatus {
  const candidate = typeof value === "object" && value !== null ? value as Partial<BackupStatus> : {};
  const normalizeTimestamp = (timestamp: unknown) => typeof timestamp === "string" && Number.isFinite(Date.parse(timestamp)) ? timestamp : null;
  return { savedAt: normalizeTimestamp(candidate.savedAt), restoredAt: normalizeTimestamp(candidate.restoredAt) };
}

export async function loadBackupStatus(): Promise<BackupStatus> {
  try {
    const raw = await AsyncStorage.getItem(BACKUP_STATUS_KEY);
    if (!raw) return defaultBackupStatus;
    return normalizeBackupStatus(JSON.parse(raw));
  } catch { return defaultBackupStatus; }
}

export async function saveBackupStatus(status: BackupStatus) {
  await AsyncStorage.setItem(BACKUP_STATUS_KEY, serializeLocalValue(normalizeBackupStatus(status)));
}

export function normalizeSecurityPreferences(value: unknown) {
  const candidate = typeof value === "object" && value !== null ? value as Partial<SecurityPreferences> : {};
  const timeout = candidate.lockTimeoutSeconds === 0 || candidate.lockTimeoutSeconds === 60 || candidate.lockTimeoutSeconds === 300 || candidate.lockTimeoutSeconds === 900 ? candidate.lockTimeoutSeconds : defaultSecurityPreferences.lockTimeoutSeconds;
  return { biometricLock: candidate.biometricLock === true, lockTimeoutSeconds: timeout };
}
export const defaultPrepPreferences: PrepPreferences = { rangeDays: 14, questions: ["What patterns should I pay attention to?", "Could my sleep routine be worth discussing?", "What should I track before our next visit?"], context: defaultClinicianContext };

export function isOnboardingAccepted(value: string | null) {
  return value === "accepted";
}

export function shouldConfirmClear(entryCount: number) {
  return entryCount > 0;
}

export async function loadSecurityPreferences(): Promise<SecurityPreferences> {
  const raw = await AsyncStorage.getItem(SECURITY_KEY);
  if (!raw) return defaultSecurityPreferences;
  try { return normalizeSecurityPreferences(JSON.parse(raw)); } catch { return defaultSecurityPreferences; }
}

export async function saveSecurityPreferences(preferences: SecurityPreferences) {
  await AsyncStorage.setItem(SECURITY_KEY, serializeLocalValue(normalizeSecurityPreferences(preferences)));
}

async function getBackupKey() {
  if (!isNativePlatform) throw new Error("Secure backups require a native device");
  const SecureStore = await import("expo-secure-store");
  const existing = await SecureStore.getItemAsync(BACKUP_KEY, { requireAuthentication: true, authenticationPrompt: "Unlock your journal backup" });
  if (existing) return existing;
  const marker = `journal-backup-${Date.now()}`;
  await SecureStore.setItemAsync(BACKUP_KEY, marker, { requireAuthentication: true, authenticationPrompt: "Protect your journal backup" });
  return marker;
}

export async function createEncryptedBackup(entries: HealthEntry[]) {
  const SecureStore = await import("expo-secure-store");
  await getBackupKey();
  const serialized = JSON.stringify({ version: 1, createdAt: new Date().toISOString(), entries });
  const chunkSize = 1500;
  const count = Math.ceil(serialized.length / chunkSize);
  for (let index = 0; index < count; index += 1) {
    await SecureStore.setItemAsync(`ai-health-journal.backup.chunk.${index}`, serialized.slice(index * chunkSize, (index + 1) * chunkSize), { requireAuthentication: true, authenticationPrompt: "Protect your journal backup" });
  }
  await SecureStore.setItemAsync(BACKUP_META_KEY, serializeLocalValue({ version: 1, count }), { requireAuthentication: true, authenticationPrompt: "Protect your journal backup" });
  return count;
}

export async function restoreEncryptedBackup() {
  if (!isNativePlatform) throw new Error("Secure backups require a native device");
  const SecureStore = await import("expo-secure-store");
  await getBackupKey();
  const metaRaw = await SecureStore.getItemAsync(BACKUP_META_KEY, { requireAuthentication: true, authenticationPrompt: "Unlock your journal backup" });
  if (!metaRaw) throw new Error("No encrypted backup found");
  const meta = JSON.parse(metaRaw) as { version?: number; count?: number };
  if (meta.version !== 1 || !meta.count || meta.count < 1 || meta.count > 100) throw new Error("Invalid encrypted backup");
  let serialized = "";
  for (let index = 0; index < meta.count; index += 1) {
    const chunk = await SecureStore.getItemAsync(`ai-health-journal.backup.chunk.${index}`, { requireAuthentication: true, authenticationPrompt: "Unlock your journal backup" });
    if (!chunk) throw new Error("Incomplete encrypted backup");
    serialized += chunk;
  }
  const content = JSON.parse(serialized) as { version?: number; entries?: HealthEntry[] };
  if (content.version !== 1 || !Array.isArray(content.entries)) throw new Error("Invalid encrypted backup contents");
  return content.entries;
}

export type AppointmentSymptomSummary = { name: string; count: number; averageSeverity: number; minSeverity: number; maxSeverity: number; evidenceDates: string[] };
export type AppointmentSnapshot = { rangeDays: number; daysLogged: number; coveragePercent: number; notesLogged: number; symptomDays: number; averageMood: number; moodRange: { min: number; max: number }; averageSleepHours: number; sleepRange: { min: number; max: number }; averageActivityMinutes: number; highestSelfRatedSeverity: number; symptoms: AppointmentSymptomSummary[] };
function symptomAggregationKey(name: string) {
  return name.trim().toLocaleLowerCase();
}
export function buildAppointmentSnapshot(entries: HealthEntry[], rangeDays = 14): AppointmentSnapshot {
  const boundedRange = Math.max(1, Math.min(30, Math.floor(rangeDays)));
  const recent = entries.slice(0, boundedRange);
  const average = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
  const symptomMap = new Map<string, { name: string; count: number; severityTotal: number; minSeverity: number; maxSeverity: number; evidenceDates: string[] }>();
  recent.forEach((entry) => {
    const dailySymptoms = new Map<string, { name: string; severity: number }>();
    entry.symptoms.forEach((symptom) => {
      const key = symptomAggregationKey(symptom.name);
      const current = dailySymptoms.get(key);
      if (!current || symptom.severity > current.severity) dailySymptoms.set(key, { name: symptom.name.trim(), severity: symptom.severity });
    });
    dailySymptoms.forEach((symptom, key) => {
      const current = symptomMap.get(key) ?? { name: symptom.name, count: 0, severityTotal: 0, minSeverity: 5, maxSeverity: 0, evidenceDates: [] };
      current.count += 1;
      current.severityTotal += symptom.severity;
      current.minSeverity = Math.min(current.minSeverity, symptom.severity);
      current.maxSeverity = Math.max(current.maxSeverity, symptom.severity);
      current.evidenceDates.push(entry.date);
      symptomMap.set(key, current);
    });
  });
  return {
    rangeDays: boundedRange,
    daysLogged: recent.length,
    coveragePercent: Math.round(recent.length / boundedRange * 100),
    notesLogged: recent.filter((entry) => entry.notes.trim().length > 0).length,
    symptomDays: recent.filter((entry) => entry.symptoms.length > 0).length,
    averageMood: average(recent.map((entry) => entry.mood)),
    moodRange: { min: recent.length ? Math.min(...recent.map((entry) => entry.mood)) : 0, max: recent.length ? Math.max(...recent.map((entry) => entry.mood)) : 0 },
    averageSleepHours: average(recent.map((entry) => entry.sleepHours)),
    sleepRange: { min: recent.length ? Math.min(...recent.map((entry) => entry.sleepHours)) : 0, max: recent.length ? Math.max(...recent.map((entry) => entry.sleepHours)) : 0 },
    averageActivityMinutes: average(recent.map((entry) => entry.activityMinutes)),
    highestSelfRatedSeverity: Math.max(0, ...recent.flatMap((entry) => entry.symptoms.map((symptom) => symptom.severity))),
    symptoms: [...symptomMap.entries()]
      .map(([, value]) => ({ name: value.name, count: value.count, averageSeverity: Number((value.severityTotal / value.count).toFixed(1)), minSeverity: value.minSeverity, maxSeverity: value.maxSeverity, evidenceDates: [...new Set(value.evidenceDates)] }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name)),
  };
}
export const clinicianReviewChecklist = [
  "What changed from your usual pattern?",
  "When did the change start, and how often did it occur?",
  "How long did each episode or change last?",
  "What situations, routines, or factors were present around it?",
  "What, if anything, seemed to make it better or worse?",
  "How did it affect sleep, activity, work, or daily routines?",
  "Did your ability to do usual activities change?",
  "Which questions do you want to ask during the visit?",
] as const;
export function normalizeClinicianQuestions(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((question): question is string => typeof question === "string")
    .map((question) => question.trim().slice(0, 240))
    .filter(Boolean)
    .slice(0, 10);
}
export function normalizeClinicianReportFields(value: unknown): ClinicianReportFields {
  const candidate = typeof value === "object" && value !== null ? value as Partial<ClinicianReportFields> : {};
  return { mood: candidate.mood !== false, sleep: candidate.sleep !== false, activity: candidate.activity !== false, symptoms: candidate.symptoms !== false, noteStatus: candidate.noteStatus !== false, questions: candidate.questions !== false, context: candidate.context !== false };
}
export function clinicianReportHasContent(entries: HealthEntry[], questions: string[], context: ClinicianContext, selectedFields: ClinicianReportFields): boolean {
  const fields = normalizeClinicianReportFields(selectedFields);
  const normalizedContext = normalizeClinicianContext(context);
  const entryFieldSelected = fields.mood || fields.sleep || fields.activity || fields.symptoms || fields.noteStatus;
  return (entries.length > 0 && entryFieldSelected) || (fields.questions && normalizeClinicianQuestions(questions).length > 0) || (fields.context && Object.values(normalizedContext).some(Boolean));
}
function formatClinicianReportEntry(entry: HealthEntry, fields: ClinicianReportFields): string {
  const parts = [
    fields.mood ? `mood ${entry.mood}/5` : "",
    fields.sleep ? `sleep ${entry.sleepHours}h` : "",
    fields.activity ? `activity ${entry.activityMinutes}m` : "",
    fields.noteStatus && entry.notes.trim() ? "note recorded" : "",
    fields.symptoms && entry.symptoms.length ? `symptoms ${entry.symptoms.map((item) => `${item.name} (${item.severity}/5)`).join(", ")}` : "",
  ].filter(Boolean);
  return `${formatDay(entry.date)}${parts.length ? `: ${parts.join(", ")}` : ""}`;
}
function formatClinicianReportSnapshot(snapshot: ReturnType<typeof buildAppointmentSnapshot>, fields: ClinicianReportFields): string {
  const symptomLines = snapshot.symptoms.slice(0, 5).map((symptom) => `- ${symptom.name}: ${symptom.count} logged day${symptom.count === 1 ? "" : "s"}, average self-rated severity ${symptom.averageSeverity}/5 (range ${symptom.minSeverity}–${symptom.maxSeverity}/5); evidence: ${symptom.evidenceDates.map(formatDay).join(", ")}`);
  return [`Appointment snapshot — last ${snapshot.rangeDays} days`, `Logged days: ${snapshot.daysLogged} (${snapshot.coveragePercent}% of selected days)`, fields.noteStatus && `Notes recorded: ${snapshot.notesLogged} days`, fields.symptoms && `Symptoms recorded: ${snapshot.symptomDays} days`, fields.mood && `Average self-rated mood: ${snapshot.averageMood.toFixed(1)}/5`, fields.mood && `Self-rated mood range: ${snapshot.moodRange.min}–${snapshot.moodRange.max}/5`, fields.sleep && `Average sleep: ${snapshot.averageSleepHours.toFixed(1)} hours`, fields.sleep && `Self-reported sleep range: ${snapshot.sleepRange.min.toFixed(1)}–${snapshot.sleepRange.max.toFixed(1)} hours`, fields.activity && `Average reported activity: ${snapshot.averageActivityMinutes.toFixed(0)} minutes`, fields.symptoms && `Highest self-rated symptom severity: ${snapshot.highestSelfRatedSeverity}/5`, fields.symptoms ? `Symptoms to review:\n${symptomLines.length ? symptomLines.join("\n") : "- No symptoms recorded."}` : ""].filter(Boolean).join("\n");
}
export function formatDoctorReport(entries: HealthEntry[], questions: string[], context: ClinicianContext = defaultClinicianContext, rangeDays: 7 | 14 | 30 = 14, selectedFields: ClinicianReportFields = defaultClinicianReportFields, mode: ClinicianReportMode = "detailed") {
  const recent = entries.slice(0, rangeDays);
  const normalizedContext = normalizeClinicianContext(context);
  const normalizedQuestions = normalizeClinicianQuestions(questions);
  const fields = normalizeClinicianReportFields(selectedFields);
  const snapshot = buildAppointmentSnapshot(entries, rangeDays);
  const lines = recent.map((entry) => formatClinicianReportEntry(entry, fields));
  const snapshotLines = formatClinicianReportSnapshot(snapshot, fields);
  const reviewText = `Clinician review prompts:\n${clinicianReviewChecklist.map((prompt, index) => `${index + 1}. ${prompt}`).join("\n")}`;
  const contextText = [normalizedContext.onset && `Onset: ${normalizedContext.onset}`, normalizedContext.duration && `Duration: ${normalizedContext.duration}`, normalizedContext.triggers && `Possible triggers or changes noticed: ${normalizedContext.triggers}`, normalizedContext.impact && `Daily-life impact: ${normalizedContext.impact}`].filter(Boolean).join("\n") || "None added.";
  const sections = [`AI Health Journal — ${mode === "concise" ? "appointment summary" : "recent notes"}`, snapshotLines, `Evidence details:\n${lines.length ? lines.join("\n") : "No entries recorded in this period."}`, mode === "concise" ? "" : reviewText, fields.context ? `User-provided context:\n${contextText}` : "", fields.questions ? `Questions to discuss:\n${normalizedQuestions.length ? normalizedQuestions.map((question, index) => `${index + 1}. ${question}`).join("\n") : "None saved."}` : ""].filter(Boolean);
  return `${sections.join("\n\n")}\n\nThis is a summary of personal notes, not a diagnosis or treatment recommendation. Discuss changes, severe symptoms, or urgent concerns with a qualified healthcare professional.`;
}

export async function loadOptionalLocalString(key: string): Promise<{ value: string | null; recovered: boolean }> {
  try {
    return { value: await AsyncStorage.getItem(key), recovered: false };
  } catch {
    return { value: null, recovered: true };
  }
}

export async function loadEntries(): Promise<HealthEntry[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return normalizeHealthEntries(parsed);
  } catch { return []; }
}

export async function saveEntries(entries: HealthEntry[]) {
  await AsyncStorage.setItem(STORAGE_KEY, serializeLocalValue(normalizeHealthEntries(entries)));
}

export function normalizeJournalPreferences(value: unknown): JournalPreferences {
  const candidate = typeof value === "object" && value !== null ? value as Partial<JournalPreferences> : {};
  return {
    focus: candidate.focus === "sleep" || candidate.focus === "mood" || candidate.focus === "symptoms" ? candidate.focus : defaultPreferences.focus,
    cadence: candidate.cadence === "daily" || candidate.cadence === "weekly" || candidate.cadence === "on-demand" ? candidate.cadence : defaultPreferences.cadence,
    promptStyle: candidate.promptStyle === "concise" || candidate.promptStyle === "questions" || candidate.promptStyle === "reflective" ? candidate.promptStyle : defaultPreferences.promptStyle,
    questionStyle: candidate.questionStyle === "concise" || candidate.questionStyle === "exploratory" || candidate.questionStyle === "structured" ? candidate.questionStyle : defaultPreferences.questionStyle,
  };
}

export async function loadPreferences(): Promise<JournalPreferences> {
  let raw: string | null = null;
  try { raw = await AsyncStorage.getItem(PREFERENCES_KEY); } catch { return defaultPreferences; }
  if (!raw) return defaultPreferences;
  try { return normalizeJournalPreferences(JSON.parse(raw)); } catch { return defaultPreferences; }
}

export async function loadRetentionPreference(): Promise<RetentionPreference> {
  try {
    const raw = await AsyncStorage.getItem(RETENTION_KEY);
    return raw ? normalizeRetentionPreference(JSON.parse(raw)) : defaultRetentionPreference;
  } catch {
    return defaultRetentionPreference;
  }
}

export async function saveRetentionPreference(preference: RetentionPreference) {
  await AsyncStorage.setItem(RETENTION_KEY, serializeLocalValue(normalizeRetentionPreference(preference)));
}

export async function savePreferences(preferences: JournalPreferences) {
  await AsyncStorage.setItem(PREFERENCES_KEY, serializeLocalValue(normalizeJournalPreferences(preferences)));
}

export async function loadAnalyticsContextAnnotations(): Promise<AnalyticsContextAnnotation[]> {
  try {
    const raw = await AsyncStorage.getItem(ANALYTICS_CONTEXT_KEY);
    return raw ? normalizeAnalyticsContextAnnotations(JSON.parse(raw)) : [];
  } catch {
    return [];
  }
}

export async function saveAnalyticsContextAnnotations(annotations: AnalyticsContextAnnotation[]) {
  await AsyncStorage.setItem(ANALYTICS_CONTEXT_KEY, serializeLocalValue(normalizeAnalyticsContextAnnotations(annotations)));
}

export type AnalyticsContextRetryResult =
  | { status: "success"; value: AnalyticsContextAnnotation[] }
  | { status: "error"; error: unknown }
  | { status: "busy" };

export function createAnalyticsContextRetry(loader: () => Promise<AnalyticsContextAnnotation[]>) {
  let inFlight = false;
  return async (): Promise<AnalyticsContextRetryResult> => {
    if (inFlight) return { status: "busy" };
    inFlight = true;
    try {
      return { status: "success", value: await loader() };
    } catch (error) {
      return { status: "error", error };
    } finally {
      inFlight = false;
    }
  };
}

export function normalizeClinicianContext(value: unknown): ClinicianContext {
  const candidate = typeof value === "object" && value !== null ? value as Partial<ClinicianContext> : {};
  const normalize = (item: unknown) => typeof item === "string" ? item.trim().slice(0, 240) : "";
  return { onset: normalize(candidate.onset), duration: normalize(candidate.duration), triggers: normalize(candidate.triggers), impact: normalize(candidate.impact) };
}
export function normalizePrepPreferences(value: unknown): PrepPreferences {
  const candidate = typeof value === "object" && value !== null ? value as Partial<PrepPreferences> : {};
  const questions = Array.isArray(candidate.questions) ? candidate.questions.flatMap((item) => {
    if (typeof item !== "string") return [];
    const normalized = item.trim().slice(0, 240);
    return normalized ? [normalized] : [];
  }) : defaultPrepPreferences.questions;
  return {
    rangeDays: candidate.rangeDays === 7 || candidate.rangeDays === 14 || candidate.rangeDays === 30 ? candidate.rangeDays : defaultPrepPreferences.rangeDays,
    questions: questions.length > 0 ? questions : defaultPrepPreferences.questions,
    context: normalizeClinicianContext(candidate.context),
  };
}

export async function loadPrepPreferences(): Promise<PrepPreferences> {
  let raw: string | null = null;
  try { raw = await AsyncStorage.getItem(PREP_KEY); } catch { return defaultPrepPreferences; }
  if (!raw) return defaultPrepPreferences;
  try { return normalizePrepPreferences(JSON.parse(raw)); } catch { return defaultPrepPreferences; }
}

export async function savePrepPreferences(preferences: PrepPreferences) {
  await AsyncStorage.setItem(PREP_KEY, serializeLocalValue(normalizePrepPreferences(preferences)));
}

export const defaultPrepChecklist = [false, false, false] as const;

export function normalizePrepChecklist(value: unknown): boolean[] {
  if (!Array.isArray(value)) return [...defaultPrepChecklist];
  return [0, 1, 2].map((index) => value[index] === true);
}

export async function loadPrepChecklist(): Promise<boolean[]> {
  try { const raw = await AsyncStorage.getItem(CHECKLIST_KEY); return raw ? normalizePrepChecklist(JSON.parse(raw)) : [...defaultPrepChecklist]; } catch { return [...defaultPrepChecklist]; }
}

export async function savePrepChecklist(checklist: boolean[]) {
  await AsyncStorage.setItem(CHECKLIST_KEY, serializeLocalValue(normalizePrepChecklist(checklist)));
}

export function normalizePrepChecklistLabel(value: unknown): string {
  if (typeof value !== "string") return "Add anything you want to remember";
  const trimmed = value.trim().slice(0, 80);
  return trimmed || "Add anything you want to remember";
}

export async function loadPrepChecklistLabel(): Promise<string> {
  try { return normalizePrepChecklistLabel(await AsyncStorage.getItem(CHECKLIST_LABEL_KEY)); } catch { return "Add anything you want to remember"; }
}

export async function savePrepChecklistLabel(label: string) {
  await AsyncStorage.setItem(CHECKLIST_LABEL_KEY, serializeLocalValue(normalizePrepChecklistLabel(label)));
}

export function serializeJournal(entries: HealthEntry[]) {
  return JSON.stringify({ version: 2, exportedAt: new Date().toISOString(), entries: normalizeHealthEntries(entries) }, null, 2);
}

export function parseJournalExportWithReport(raw: string): { entries: HealthEntry[]; discardedCount: number } {
  if (!raw.trim()) throw new Error("Empty journal export");
  let parsed: { version?: number; entries?: unknown };
  try { parsed = JSON.parse(raw) as { version?: number; entries?: unknown }; } catch { throw new Error("Malformed journal export"); }
  if (parsed.version !== 1 && parsed.version !== 2 || !Array.isArray(parsed.entries)) throw new Error("Unsupported journal export");
  const entries = normalizeHealthEntries(parsed.entries);
  if (!entries.length && parsed.entries.length) throw new Error("Invalid journal entries");
  return { entries, discardedCount: parsed.entries.length - entries.length };
}

export type JournalImportPreview = {
  version: 1 | 2;
  entryCount: number;
  skippedCount: number;
  firstDate: string | null;
  lastDate: string | null;
};

export type JournalUndoSnapshot = {
  entries: HealthEntry[];
  importedEntries?: HealthEntry[];
  createdAt: string;
};

export function previewJournalImport(raw: string): JournalImportPreview {
  if (!raw.trim()) throw new Error("Empty journal export");
  let parsed: { version?: number; entries?: unknown };
  try { parsed = JSON.parse(raw) as { version?: number; entries?: unknown }; } catch { throw new Error("Malformed journal export"); }
  if ((parsed.version !== 1 && parsed.version !== 2) || !Array.isArray(parsed.entries)) throw new Error("Unsupported journal export");
  const report = parseJournalExportWithReport(raw);
  const dates = report.entries.map((entry) => entry.date).sort();
  return { version: parsed.version, entryCount: report.entries.length, skippedCount: report.discardedCount, firstDate: dates[0] ?? null, lastDate: dates[dates.length - 1] ?? null };
}

export function createJournalUndoSnapshot(entries: HealthEntry[], createdAt = new Date().toISOString(), importedEntries?: HealthEntry[]): JournalUndoSnapshot {
  return { entries: normalizeHealthEntries(entries).slice(0, 365), importedEntries: importedEntries ? normalizeHealthEntries(importedEntries).slice(0, 365) : undefined, createdAt };
}

export function invalidateJournalUndoSnapshot(): null {
  return null;
}

export async function persistLocalActivityBestEffort(
  activity: LocalActivityEvent[],
  saveActivity: (activity: LocalActivityEvent[]) => Promise<void>,
): Promise<boolean> {
  try {
    await saveActivity(activity);
    return true;
  } catch {
    return false;
  }
}

export async function replaceJournalDataset(
  entries: HealthEntry[],
  clearUndoSnapshot: () => Promise<void>,
  saveNextEntries: (entries: HealthEntry[]) => Promise<void>,
): Promise<HealthEntry[]> {
  const normalized = normalizeHealthEntries(entries);
  await saveNextEntries(normalized);
  await clearUndoSnapshot();
  return normalized;
}

export function journalUndoAgeMs(snapshot: JournalUndoSnapshot | null, now = Date.now()): number | null {
  if (!snapshot || !Number.isFinite(now)) return null;
  const createdAtMs = Date.parse(snapshot.createdAt);
  if (!Number.isFinite(createdAtMs)) return null;
  return now - createdAtMs;
}

export function canUndoJournalImport(snapshot: JournalUndoSnapshot | null, now = Date.now(), maxAgeMs = 10 * 60 * 1000): boolean {
  if (!Number.isFinite(maxAgeMs) || maxAgeMs < 0) return false;
  const ageMs = journalUndoAgeMs(snapshot, now);
  return ageMs !== null && ageMs >= 0 && ageMs <= maxAgeMs;
}

export function canApplyJournalUndo(snapshot: JournalUndoSnapshot | null, currentEntries: HealthEntry[], importedEntries: HealthEntry[], now = Date.now()): boolean {
  if (!snapshot || !canUndoJournalImport(snapshot, now)) return false;
  const current = normalizeHealthEntries(currentEntries);
  const imported = normalizeHealthEntries(snapshot.importedEntries ?? importedEntries);
  return JSON.stringify(current) === JSON.stringify(imported);
}

export function normalizeJournalUndoSnapshot(value: unknown): JournalUndoSnapshot | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Partial<JournalUndoSnapshot>;
  if (typeof candidate.createdAt !== "string" || !Number.isFinite(Date.parse(candidate.createdAt)) || !Array.isArray(candidate.entries)) return null;
  const entries = normalizeHealthEntries(candidate.entries).slice(0, 365);
  const importedEntries = Array.isArray(candidate.importedEntries) ? normalizeHealthEntries(candidate.importedEntries).slice(0, 365) : undefined;
  return { entries, importedEntries, createdAt: candidate.createdAt };
}

export async function loadJournalUndoSnapshot(): Promise<JournalUndoSnapshot | null> {
  try {
    const raw = await AsyncStorage.getItem(IMPORT_UNDO_KEY);
    const snapshot = raw ? normalizeJournalUndoSnapshot(JSON.parse(raw)) : null;
    return canUndoJournalImport(snapshot) ? snapshot : null;
  } catch { return null; }
}

export async function saveJournalUndoSnapshot(snapshot: JournalUndoSnapshot) {
  await AsyncStorage.setItem(IMPORT_UNDO_KEY, serializeLocalValue(createJournalUndoSnapshot(snapshot.entries, snapshot.createdAt, snapshot.importedEntries)));
}

export async function clearJournalUndoSnapshot() {
  await AsyncStorage.removeItem(IMPORT_UNDO_KEY);
}

export function parseJournalExport(raw: string): HealthEntry[] {
  return parseJournalExportWithReport(raw).entries;
}

export function reflectionPrompts(preferences: JournalPreferences, entries: HealthEntry[]) {
  if (!entries.length) return [preferences.promptStyle === "questions" ? "What would you like to ask about your day?" : "What would you like to notice about your day?"];
  const topSymptom = entries.flatMap((entry) => entry.symptoms.map((symptom) => symptom.name))[0];
  const base = {
    sleep: [`You logged ${entries[0].sleepHours} hours of sleep. What did you notice?`, "What would be useful to mention about your sleep at a visit?"],
    mood: [`You logged mood at ${entries[0].mood}/5. What was happening around that rating?`, "What seemed to support or change your mood?"],
    symptoms: [topSymptom ? `You logged ${topSymptom}. What details could help describe it?` : "What details would help describe a symptom?", "What question would you like to bring to your clinician?"]
  }[preferences.focus];
  if (preferences.promptStyle === "concise") return [base[0]];
  if (preferences.promptStyle === "questions") return base.map((prompt) => prompt.endsWith("?") ? prompt : `${prompt.replace(/[.]$/, "")}?`);
  return base;
}

export function buildClinicianQuestions(entries: HealthEntry[], rangeDays = 14, style: JournalPreferences["questionStyle"] = "structured") {
  if (!entries.length) return ["What should I track before my next visit?"];
  const questions: string[] = [];
  const averageSleep = entries.reduce((sum, entry) => sum + entry.sleepHours, 0) / entries.length;
  const averageMood = entries.reduce((sum, entry) => sum + entry.mood, 0) / entries.length;
  const symptomMap = new Map<string, { name: string; count: number; severityTotal: number }>();
  entries.forEach((entry) => {
    const dailySymptoms = new Map<string, { name: string; severity: number }>();
    entry.symptoms.forEach((symptom) => {
      const key = symptomAggregationKey(symptom.name);
      const current = dailySymptoms.get(key);
      if (!current || symptom.severity > current.severity) dailySymptoms.set(key, { name: symptom.name.trim(), severity: symptom.severity });
    });
    dailySymptoms.forEach((symptom, key) => {
      const current = symptomMap.get(key) ?? { name: symptom.name, count: 0, severityTotal: 0 };
      current.count += 1;
      current.severityTotal += symptom.severity;
      symptomMap.set(key, current);
    });
  });
  const topSymptom = [...symptomMap.entries()].sort((a, b) => b[1].count - a[1].count || a[0].localeCompare(b[0]))[0];
  if (averageSleep < 6) questions.push(`Could we discuss my sleep notes from the last ${rangeDays} days?`);
  if (averageMood < 3) questions.push("I logged several lower mood ratings. What would be useful to monitor or discuss?");
  if (topSymptom) {
    const [, detail] = topSymptom;
    const averageSeverity = (detail.severityTotal / detail.count).toFixed(1);
    questions.push(`I logged ${detail.name.toLowerCase()} on ${detail.count} day${detail.count === 1 ? "" : "s"}, with average self-rated severity ${averageSeverity}/5. What additional context would be useful to discuss?`);
  }
  const fallback = style === "concise" ? "What should I track next?" : style === "exploratory" ? "What else would be useful to notice before our next visit?" : "What should I track before our next visit?";
  return [...questions, fallback].slice(0, 3).map((question) => style === "concise" ? question.replace("Could we discuss my ", "Discuss ").replace("I logged ", "Logged ").replace(" What additional context would be useful to discuss?", ".").replace("I logged several lower mood ratings. What would be useful to monitor or discuss?", "Discuss lower mood ratings.") : question);
}

export async function clearJournalData() {
  await AsyncStorage.removeItem(STORAGE_KEY);
}

export function formatDay(isoDate: string) {
  return new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric" }).format(new Date(`${isoDate}T12:00:00`));
}

export function formatEvidenceSource(entry: HealthEntry) {
  return { mood: `Mood ${entry.mood}/5`, sleep: `Sleep ${entry.sleepHours}h`, symptoms: entry.symptoms.length ? entry.symptoms.map((symptom) => `${symptom.name} (${symptom.severity}/5)`).join(", ") : "No symptoms recorded", note: entry.notes || "No note added." };
}

export function rememberDraft(history: string[][], current: string[], limit = 3) {
  return [current, ...history.filter((draft) => draft.join("|") !== current.join("|"))].slice(0, limit);
}

export type DraftMetadata = { savedAt: string; rangeDays: 7 | 14 | 30 };

export function normalizeDraftMetadata(value: unknown): DraftMetadata[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is DraftMetadata => Boolean(item) && typeof item === "object" && typeof (item as DraftMetadata).savedAt === "string" && [7, 14, 30].includes((item as DraftMetadata).rangeDays)).slice(0, 3);
}

export async function loadDraftMetadata(): Promise<DraftMetadata[]> {
  try { return normalizeDraftMetadata(JSON.parse((await AsyncStorage.getItem(DRAFT_META_KEY)) ?? "[]")); } catch { return []; }
}

export async function saveDraftMetadata(metadata: DraftMetadata[]) {
  await AsyncStorage.setItem(DRAFT_META_KEY, serializeLocalValue(normalizeDraftMetadata(metadata)));
}

export function normalizeDraftHistory(value: unknown): string[][] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((draft): draft is string[] => Array.isArray(draft) && draft.every((item) => typeof item === "string"))
    .slice(0, 3)
    .map((draft) => draft.map((field) => field.trim()));
}

export async function loadDraftHistory(): Promise<string[][]> {
  try { return normalizeDraftHistory(JSON.parse((await AsyncStorage.getItem(DRAFT_HISTORY_KEY)) ?? "[]")); } catch { return []; }
}

export async function saveDraftHistory(history: string[][]) {
  await AsyncStorage.setItem(DRAFT_HISTORY_KEY, serializeLocalValue(normalizeDraftHistory(history)));
}

export function evidenceTimeline(dates: string[]) {
  return [...new Set(dates)].sort().map((date, index, all) => ({ date, position: all.length === 1 ? 50 : Math.round(index / (all.length - 1) * 100) }));
}

export function summarize(entries: HealthEntry[]): JournalInsight[] {
  if (!entries.length) return [];
  const insights: JournalInsight[] = [];
  const averageSleep = entries.reduce((sum, entry) => sum + entry.sleepHours, 0) / entries.length;
  const averageMood = entries.reduce((sum, entry) => sum + entry.mood, 0) / entries.length;
  const symptoms = new Map<string, number>();
  entries.forEach((entry) => entry.symptoms.forEach((symptom) => symptoms.set(symptom.name, (symptoms.get(symptom.name) ?? 0) + 1)));
  const topSymptom = [...symptoms.entries()].sort((a, b) => b[1] - a[1])[0];

  insights.push({
    title: `Average sleep: ${averageSleep.toFixed(1)} hours`,
    detail: `Personal baseline from ${entries.length} logged day${entries.length === 1 ? "" : "s"}; descriptive only.`,
    tone: averageSleep < 6 ? "attention" : "calm",
    evidenceDates: entries.map((entry) => entry.date),
    evidenceCount: entries.length,
  });
  insights.push({
    title: `Average mood: ${averageMood.toFixed(1)} of 5`,
    detail: `Based on ${entries.length} self-reported rating${entries.length === 1 ? "" : "s"}; not a clinical assessment.`,
    tone: averageMood < 3 ? "attention" : "calm",
    evidenceDates: entries.map((entry) => entry.date),
    evidenceCount: entries.length,
  });
  if (topSymptom) {
    insights.push({
      title: `${topSymptom[0]} appeared ${topSymptom[1]} time${topSymptom[1] === 1 ? "" : "s"}`,
      detail: "Consider whether this is worth mentioning at your next appointment.",
      tone: topSymptom[1] >= 3 ? "attention" : "calm",
      evidenceDates: entries.filter((entry) => entry.symptoms.some((symptom) => symptom.name === topSymptom[0])).map((entry) => entry.date),
      evidenceCount: topSymptom[1],
    });
  }
  return insights;
}

export function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

export function updateEntry(entries: HealthEntry[], updated: HealthEntry) {
  return entries.map((entry) => entry.id === updated.id ? updated : entry);
}

export function trendSummary(entries: HealthEntry[]) {
  const recent = entries.slice(0, 7);
  const average = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
  const symptomCounts = new Map<string, number>();
  recent.forEach((entry) => entry.symptoms.forEach((symptom) => symptomCounts.set(symptom.name, (symptomCounts.get(symptom.name) ?? 0) + 1)));
  return {
    days: recent.length,
    averageSleep: average(recent.map((entry) => entry.sleepHours)),
    averageMood: average(recent.map((entry) => entry.mood)),
    topSymptoms: [...symptomCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3),
  };
}


export type PremiumPlan = "none" | "monthly" | "annual";
export type PremiumSource = "none" | "app_store" | "play_store" | "test";

export interface PremiumEntitlement {
  active: boolean;
  plan: PremiumPlan;
  source: PremiumSource;
  checkedAt: string | null;
}

export const defaultPremiumEntitlement: PremiumEntitlement = {
  active: false,
  plan: "none",
  source: "none",
  checkedAt: null,
};

export function normalizePremiumEntitlement(value: unknown): PremiumEntitlement {
  if (!value || typeof value !== "object") return defaultPremiumEntitlement;
  const candidate = value as Partial<PremiumEntitlement>;
  const active = candidate.active === true;
  const plan = candidate.plan === "monthly" || candidate.plan === "annual" ? candidate.plan : "none";
  const source = candidate.source === "app_store" || candidate.source === "play_store" || candidate.source === "test" ? candidate.source : "none";
  if (!active || plan === "none" || source === "none") return defaultPremiumEntitlement;
  return {
    active: true,
    plan,
    source,
    checkedAt: typeof candidate.checkedAt === "string" ? candidate.checkedAt : null,
  };
}


export interface PremiumProduct {
  id: "journal_pro_monthly" | "journal_pro_annual";
  plan: "monthly" | "annual";
  billingPeriod: "P1M" | "P1Y";
}

export const premiumProducts: readonly PremiumProduct[] = [
  { id: "journal_pro_monthly", plan: "monthly", billingPeriod: "P1M" },
  { id: "journal_pro_annual", plan: "annual", billingPeriod: "P1Y" },
];

export function premiumProductForPlan(plan: "monthly" | "annual"): PremiumProduct {
  return premiumProducts.find((product) => product.plan === plan) ?? premiumProducts[1];
}

export type PremiumStoreAvailability = "preview" | "unavailable";
export type PremiumEntitlementState = "active" | "preview" | "unavailable";

export function normalizePremiumInterest(value: unknown): boolean {
  return value === true || value === "saved";
}

export function premiumInterestStorageValue(value: boolean): "saved" | "none" {
  return value ? "saved" : "none";
}

export function normalizePremiumPlan(value: unknown): "monthly" | "annual" {
  return value === "monthly" ? "monthly" : "annual";
}

export function premiumPlanStorageValue(value: "monthly" | "annual"): "monthly" | "annual" {
  return normalizePremiumPlan(value);
}

/**
 * Keeps the premium UI honest when billing contracts or store products are not ready.
 * This function never inspects journal entries or infers a purchase from local data.
 */
export function premiumEntitlementState(
  entitlement: PremiumEntitlement,
  storeAvailability: PremiumStoreAvailability,
): PremiumEntitlementState {
  if (entitlement.active) return "active";
  return storeAvailability === "preview" ? "preview" : "unavailable";
}

/**
 * Calculates annual savings only from store-provided numeric prices.
 * Invalid, zero, or negative values return null rather than showing a fabricated claim.
 */
export function premiumAnnualSavingsPercent(monthlyPrice: number, annualPrice: number): number | null {
  if (!Number.isFinite(monthlyPrice) || !Number.isFinite(annualPrice) || monthlyPrice <= 0 || annualPrice <= 0) return null;
  const annualMonthlyEquivalent = monthlyPrice * 12;
  if (annualPrice >= annualMonthlyEquivalent) return 0;
  return Math.round((1 - annualPrice / annualMonthlyEquivalent) * 100);
}


export type AnalyticsCoverage = {
  windowDays: number;
  daysLogged: number;
  coveragePercent: number;
  missingDays: number;
  metricCoverage: { sleep: number; mood: number; symptoms: number; notes: number };
};

export function analyticsCoverage(entries: HealthEntry[], windowDays = 14): AnalyticsCoverage {
  const safeWindow = Math.max(1, Math.floor(windowDays));
  const uniqueDates = new Set(entries.map((entry) => entry.date));
  const daysLogged = Math.min(safeWindow, uniqueDates.size);
  const metricCoverage = {
    sleep: entries.filter((entry) => Number.isFinite(entry.sleepHours)).length,
    mood: entries.filter((entry) => Number.isFinite(entry.mood)).length,
    symptoms: entries.filter((entry) => entry.symptoms.length > 0).length,
    notes: entries.filter((entry) => entry.notes.trim().length > 0).length,
  };
  return {
    windowDays: safeWindow,
    daysLogged,
    coveragePercent: Math.round(daysLogged / safeWindow * 100),
    missingDays: Math.max(0, safeWindow - daysLogged),
    metricCoverage,
  };
}

export type WeekOverWeekSummary = {
  recentDays: number;
  priorDays: number;
  recentAverageSleep: number;
  priorAverageSleep: number;
  sleepDelta: number;
  recentAverageMood: number;
  priorAverageMood: number;
  moodDelta: number;
  descriptiveOnly: true;
};

export function weekOverWeekSummary(entries: HealthEntry[]): WeekOverWeekSummary {
  const ordered = [...entries].sort((a, b) => a.date.localeCompare(b.date));
  const recent = ordered.slice(-7);
  const prior = ordered.slice(-14, -7);
  const average = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
  const recentAverageSleep = average(recent.map((entry) => entry.sleepHours));
  const priorAverageSleep = average(prior.map((entry) => entry.sleepHours));
  const recentAverageMood = average(recent.map((entry) => entry.mood));
  const priorAverageMood = average(prior.map((entry) => entry.mood));
  return {
    recentDays: recent.length,
    priorDays: prior.length,
    recentAverageSleep,
    priorAverageSleep,
    sleepDelta: recentAverageSleep - priorAverageSleep,
    recentAverageMood,
    priorAverageMood,
    moodDelta: recentAverageMood - priorAverageMood,
    descriptiveOnly: true,
  };
}


export type AnalyticsPoint = { date: string; sleep: number; mood: number };

export function analyticsSeries(entries: HealthEntry[], windowDays = 14): AnalyticsPoint[] {
  return [...entries]
    .slice(0, Math.max(1, Math.floor(windowDays)))
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((entry) => ({ date: entry.date, sleep: entry.sleepHours, mood: entry.mood }));
}

export function formatAnalyticsNumber(value: number, locale = "en-US") {
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 1, minimumFractionDigits: 0 }).format(value);
}

export function formatAnalyticsDate(isoDate: string, locale = "en-US") {
  return new Intl.DateTimeFormat(locale, { month: "short", day: "numeric" }).format(new Date(`${isoDate}T12:00:00`));
}


export function formatAnalyticsAccessibility(series: AnalyticsPoint[], locale = "en-US") {
  if (!series.length) return "No logged values in the selected analytics window.";
  const first = series[0];
  const last = series[series.length - 1];
  return `${series.length} logged day${series.length === 1 ? "" : "s"} from ${formatAnalyticsDate(first.date, locale)} to ${formatAnalyticsDate(last.date, locale)}. Sleep and mood values are descriptive self-reports.`;
}

export type AnalyticsSummaryDetail = "concise" | "detailed";
export function normalizeClinicianContextNotes(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((note): note is string => typeof note === "string")
    .map((note) => note.trim().slice(0, 240))
    .filter(Boolean)
    .slice(0, 5);
}

export function formatAnalyticsClinicianSummary(entries: HealthEntry[], windowDays: number, locale = "en-US", options: { detail?: AnalyticsSummaryDetail; contextNote?: string; contextNotes?: string[] } = {}) {
  const selected = entries.slice(0, Math.max(1, Math.floor(windowDays)));
  const coverage = analyticsCoverage(selected, windowDays);
  const comparison = weekOverWeekSummary(selected);
  const sourceDates = [...new Set(selected.map((entry) => entry.date))].sort();
  const average = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
  const detail = options.detail ?? "concise";
  const symptomDetails = new Map<string, { count: number; severityTotal: number; dates: string[] }>();
  selected.forEach((entry) => entry.symptoms.forEach((symptom) => {
    const current = symptomDetails.get(symptom.name) ?? { count: 0, severityTotal: 0, dates: [] };
    current.count += 1;
    current.severityTotal += symptom.severity;
    current.dates.push(entry.date);
    symptomDetails.set(symptom.name, current);
  }));
  const topSymptoms = [...symptomDetails.entries()].sort((a, b) => b[1].count - a[1].count || a[0].localeCompare(b[0])).slice(0, 3);
  const lines = [
    "AI Health Journal — descriptive analytics summary",
    `Window: ${coverage.windowDays} days | Logged days: ${coverage.daysLogged} | Coverage: ${coverage.coveragePercent}%`,
    `Average sleep: ${formatAnalyticsNumber(average(selected.map((entry) => entry.sleepHours)), locale)}h`,
    `Average mood: ${formatAnalyticsNumber(average(selected.map((entry) => entry.mood)), locale)}/5`,
    `Recent versus prior logged days: sleep ${comparison.sleepDelta >= 0 ? "+" : ""}${formatAnalyticsNumber(comparison.sleepDelta, locale)}h; mood ${comparison.moodDelta >= 0 ? "+" : ""}${formatAnalyticsNumber(comparison.moodDelta, locale)} points`,
    `Source dates: ${sourceDates.length ? sourceDates.map((date) => formatAnalyticsDate(date, locale)).join(", ") : "None"}`,
  ];
  if (detail === "detailed") {
    lines.push(`Metric coverage: sleep ${coverage.metricCoverage.sleep}, mood ${coverage.metricCoverage.mood}, symptoms ${coverage.metricCoverage.symptoms}, notes ${coverage.metricCoverage.notes}`);
    lines.push(`Most logged symptoms: ${topSymptoms.length ? topSymptoms.map(([name, detail]) => `${name} (${detail.count})`).join(", ") : "None"}`);
    lines.push(`Symptom evidence: ${topSymptoms.length ? topSymptoms.map(([name, detail]) => `${name}: average self-rated severity ${(detail.severityTotal / detail.count).toFixed(1)}/5; dates ${[...new Set(detail.dates)].map((date) => formatAnalyticsDate(date, locale)).join(", ")}`).join(" | ") : "None"}`);
  }
  const contextNotes = normalizeClinicianContextNotes([...(options.contextNotes ?? []), ...(options.contextNote?.trim() ? [options.contextNote.trim()] : [])]);
  if (contextNotes.length) lines.push(`User context notes: ${contextNotes.join(" | ")}`);
  lines.push("Descriptive personal notes only; not a diagnosis, treatment recommendation, or medical assessment.");
  return lines.join("\n");
}


export function selectAnalyticsEvidence(entries: HealthEntry[], selectedIds: string[]) {
  if (!selectedIds.length) return entries;
  const allowed = new Set(selectedIds);
  return entries.filter((entry) => allowed.has(entry.id));
}


export function applyAnalyticsEvidenceSelection(entries: HealthEntry[], selectedIds: string[] | null) {
  if (selectedIds === null) return entries;
  const allowed = new Set(selectedIds);
  return entries.filter((entry) => allowed.has(entry.id));
}

export function formatAnalyticsSourcePreview(entries: HealthEntry[], locale = "en-US", labels: { symptoms?: string; mood?: string; sleep?: string; note?: string; none?: string } = {}) {
  const copy = { symptoms: "Symptoms", mood: "Mood", sleep: "Sleep", note: "Note", none: "None logged", ...labels };
  return entries.map((entry) => {
    const symptoms = entry.symptoms.length ? entry.symptoms.map((symptom) => `${symptom.name} (${symptom.severity}/5)`).join(", ") : copy.none;
    const trimmedNote = entry.notes.trim();
    const note = trimmedNote ? `${trimmedNote.slice(0, 240)}${trimmedNote.length > 240 ? "…" : ""}` : copy.none;
    return `${formatAnalyticsDate(entry.date, locale)} | ${copy.symptoms}: ${symptoms} | ${copy.mood}: ${formatAnalyticsNumber(entry.mood, locale)}/5 | ${copy.sleep}: ${formatAnalyticsNumber(entry.sleepHours, locale)}h | ${copy.note}: ${note}`;
  }).join("\n");
}
