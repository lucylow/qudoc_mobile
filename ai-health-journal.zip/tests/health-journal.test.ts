import { beforeEach, describe, expect, it, vi } from "vitest";
import { normalizeLanguage, translate, translateMedicalReport, translateNoticeTiming, noticeTimingFeedback, languageOptions } from "../lib/i18n";
import { buildClinicianQuestions, buildAppointmentSnapshot, clinicianReviewChecklist, defaultPreferences, formatDoctorReport, formatEvidenceSource, rememberDraft, normalizeDraftHistory, evidenceTimeline, userSafeErrorMessage, userSafeErrorKind, biometricFailureMessage, isOnboardingAccepted, normalizeBackupStatus, saveBackupStatus, normalizeJournalPreferences, savePreferences, normalizeSecurityPreferences, normalizePremiumEntitlement, defaultPremiumEntitlement, premiumProducts, premiumProductForPlan, premiumEntitlementState, premiumAnnualSavingsPercent, normalizePremiumInterest, premiumInterestStorageValue, normalizePremiumPlan, premiumPlanStorageValue, defaultRetentionPreference, normalizeRetentionPreference, isValidIsoDate, daysUntilIsoDate, normalizePrepPreferences, savePrepPreferences, defaultPrepChecklist, normalizePrepChecklist, analyticsCoverage, weekOverWeekSummary, analyticsSeries, formatAnalyticsNumber, formatAnalyticsDate, formatAnalyticsAccessibility, formatAnalyticsClinicianSummary, normalizeClinicianContextNotes, normalizeClinicianContext, normalizeClinicianQuestions, normalizeClinicianReportFields, clinicianReportHasContent, formatAnalyticsSourcePreview, normalizeAnalyticsContextAnnotations, normalizeHealthEntries, saveEntries, serializeLocalValue, normalizeLocalActivity, appendLocalActivity, normalizeJournalUndoSnapshot, invalidateJournalUndoSnapshot, replaceJournalDataset, persistLocalActivityBestEffort, normalizeNoticeTiming, defaultNoticeTiming, canChangeNoticeTiming, loadNoticeTiming, loadNoticeTimingWithStatus, saveNoticeTiming, saveSecurityPreferences, canRetryNoticeTimingHydration, NOTICE_TIMING_SUCCESS_FEEDBACK_MS, noticeTimingCopyKeyFor, reduceNoticePreviewState, scheduleRoutineNoticeClear, scheduleNoticeTimingSuccessClear, withTimeout, HYDRATION_TIMEOUT_MS, HYDRATION_TIMEOUT_MESSAGE, isHydrationTimeoutError, contrastRatio, retryProgressAccessibilityLayout, ACCESSIBILITY_HEADING_ROLE, clearConfirmationAccessibilityLabel, clearConfirmationFocusTarget, deleteEntryFocusTarget, importUndoFocusTarget, settingsOperationFocusTarget, retryFocusTargetFor, retryAttemptProgress, retryCapReached, backupStatusReview, noticeLiveRegionFor, modalFocusTransition, shouldApplyModalFocusRequest, resolveModalFocusTargetId, hydrationRecoveryViewModel, canStartHydrationRetry, claimHydrationRetry, HYDRATION_MAX_ATTEMPTS, nextHydrationAttempt, canRetryHydrationAttempt, createAnalyticsContextRetry, parseJournalExportWithReport, previewJournalImport, createJournalUndoSnapshot, createDemoFallbackEntries, isDemoFallbackEntry, loadOptionalLocalString, journalUndoAgeMs, canUndoJournalImport, canApplyJournalUndo, applyAnalyticsEvidenceSelection, selectAnalyticsEvidence, parseJournalExport, reflectionPrompts, restoreEncryptedBackup, serializeJournal, shouldConfirmClear, summarize, trendSummary, updateEntry, type HealthEntry, type AnalyticsContextAnnotation, type NoticeTiming, type SecurityPreferences } from "../lib/health-journal";
const mockStorage = vi.hoisted(() => ({ data: new Map<string, string>(), failWrites: false, failReads: false }));
vi.mock("@react-native-async-storage/async-storage", () => ({ default: { getItem: async (key: string) => { if (mockStorage.failReads) throw new Error("mock storage read failure"); return mockStorage.data.get(key) ?? null; }, setItem: async (key: string, value: string) => { if (mockStorage.failWrites) throw new Error("mock storage write failure"); mockStorage.data.set(key, value); }, removeItem: async (key: string) => { mockStorage.data.delete(key); } } }));

describe("premium monetization safety", () => {
  it("keeps product selection deterministic and does not infer entitlement from journal data", () => {
    expect(premiumProducts).toHaveLength(2);
    expect(premiumProductForPlan("annual")).toMatchObject({ id: "journal_pro_annual", billingPeriod: "P1Y" });
    expect(premiumEntitlementState(defaultPremiumEntitlement, "unavailable")).toBe("unavailable");
    expect(premiumEntitlementState(defaultPremiumEntitlement, "preview")).toBe("preview");
    expect(premiumEntitlementState({ active: true, plan: "annual", source: "test", checkedAt: null }, "unavailable")).toBe("active");
  });

  it("normalizes only the explicit local interest values", () => {
    expect(normalizePremiumInterest("saved")).toBe(true);
    expect(normalizePremiumInterest(true)).toBe(true);
    expect(normalizePremiumInterest("true")).toBe(false);
    expect(normalizePremiumInterest(undefined)).toBe(false);
    expect(premiumInterestStorageValue(true)).toBe("saved");
    expect(premiumInterestStorageValue(false)).toBe("none");
  });

  it("normalizes the locally persisted premium plan preference", () => {
    expect(normalizePremiumPlan("monthly")).toBe("monthly");
    expect(normalizePremiumPlan("annual")).toBe("annual");
    expect(normalizePremiumPlan("weekly")).toBe("annual");
    expect(normalizePremiumPlan(undefined)).toBe("annual");
    expect(premiumPlanStorageValue("monthly")).toBe("monthly");
    expect(premiumPlanStorageValue("annual")).toBe("annual");
  });

  it("only reports annual savings for valid store-provided prices", () => {
    expect(premiumAnnualSavingsPercent(10, 100)).toBe(17);
    expect(premiumAnnualSavingsPercent(10, 120)).toBe(0);
    expect(premiumAnnualSavingsPercent(0, 1)).toBeNull();
    expect(premiumAnnualSavingsPercent(Number.NaN, 1)).toBeNull();
    expect(premiumAnnualSavingsPercent(10, Number.POSITIVE_INFINITY)).toBeNull();
  });
});

const entries: HealthEntry[] = [
  { id: "1", date: "2026-08-16", symptoms: [{ name: "Fatigue", severity: 2 }], mood: 3, sleepHours: 5, activityMinutes: 0, notes: "" },
  { id: "2", date: "2026-08-17", symptoms: [{ name: "Fatigue", severity: 3 }], mood: 2, sleepHours: 5.5, activityMinutes: 0, notes: "" },
  { id: "3", date: "2026-08-18", symptoms: [{ name: "Fatigue", severity: 2 }], mood: 3, sleepHours: 7, activityMinutes: 0, notes: "" },
];

describe("delete-entry focus policy", () => {
  it("returns focus to the detail trigger only when deletion fails", () => {
    expect(deleteEntryFocusTarget("entry-1", "failed")).toBe("detail:entry-1");
    expect(deleteEntryFocusTarget("entry-1", "deleted")).toBeNull();
    expect(deleteEntryFocusTarget("", "failed")).toBeNull();
    expect(deleteEntryFocusTarget("   ", "failed")).toBeNull();
  });
});

describe("import undo focus policy", () => {
  it("returns the undo banner target for expired and failed outcomes only", () => {
    expect(importUndoFocusTarget("expired")).toBe("import-undo");
    expect(importUndoFocusTarget("failed")).toBe("import-undo");
    expect(importUndoFocusTarget("undone")).toBeNull();
  });
});

describe("local serialization safety", () => {
  it("serializes supported values and rejects unsupported payloads", () => {
    expect(serializeLocalValue({ safe: true })).toBe('{"safe":true}');
    expect(() => serializeLocalValue(undefined)).toThrow("Local data could not be serialized");
    const circular: { self?: unknown } = {};
    circular.self = circular;
    expect(() => serializeLocalValue(circular)).toThrow("Local data could not be serialized");
    expect(() => serializeLocalValue(1n)).toThrow("Local data could not be serialized");
  });
});

describe("local read recovery", () => {
  it("returns a recovered null value when an optional local key cannot be read", async () => {
    mockStorage.failReads = true;
    await expect(loadOptionalLocalString("optional-key")).resolves.toEqual({ value: null, recovered: true });
  });
  it("returns the stored value without recovery when the local read succeeds", async () => {
    mockStorage.failReads = false;
    mockStorage.data.set("optional-key", "saved");
    await expect(loadOptionalLocalString("optional-key")).resolves.toEqual({ value: "saved", recovered: false });
  });
});

describe("demo fallback safety", () => {
  it("creates deterministic, clearly marked sample entries without using real journal identifiers", () => {
    const sample = createDemoFallbackEntries("2026-08-20");
    expect(sample).toHaveLength(3);
    expect(sample.map((entry) => entry.date)).toEqual(["2026-08-20", "2026-08-19", "2026-08-18"]);
    expect(sample.every(isDemoFallbackEntry)).toBe(true);
    expect(sample.every((entry) => entry.notes.includes("not your health data"))).toBe(true);
  });
  it("does not classify normal user entries as demo data", () => {
    expect(isDemoFallbackEntry({ id: "entry-1" })).toBe(false);
  });
});

describe("persisted entry safety", () => {
  it("normalizes journal entries before using the shared serialization boundary", async () => {
    await saveEntries([{ id: " entry-1 ", date: "2026-08-19", mood: 4, sleepHours: 7, activityMinutes: 15, symptoms: [{ name: " fatigue ", severity: 3 }], notes: " note " }]);
    expect(mockStorage.data.get("ai-health-journal.entries.v1")).toContain('"id":"entry-1"');
    expect(mockStorage.data.get("ai-health-journal.entries.v1")).toContain('"symptoms":[{"name":"fatigue","severity":3}]');
  });
  it("accepts a versioned envelope and drops duplicate IDs and dates deterministically", () => {
    const normalized = normalizeHealthEntries({ version: 2, entries: [{ id: "same", date: "2026-08-19", mood: 4 }, { id: "same", date: "2026-08-18", mood: 2 }, { id: "other", date: "2026-08-19", mood: 1 }] });
    expect(normalized).toHaveLength(1);
    expect(normalized[0]).toMatchObject({ id: "same", date: "2026-08-19", mood: 4 });
  });

  it("filters invalid dates and clamps numeric values before hydration", () => {
    const normalized = normalizeHealthEntries([{ id: "safe", date: "2026-08-19", symptoms: [{ name: "Pain", severity: 99 }, { name: "", severity: "bad" }], mood: -4, sleepHours: 30, activityMinutes: 2000, notes: "x".repeat(2200) }, { id: "invalid", date: "2026-02-30" }]);
    expect(normalized).toHaveLength(1);
    expect(normalized[0].symptoms).toEqual([{ name: "Pain", severity: 5 }]);
    expect(normalized[0].mood).toBe(1);
    expect(normalized[0].sleepHours).toBe(24);
    expect(normalized[0].activityMinutes).toBe(1440);
    expect(normalized[0].notes).toHaveLength(2000);
  });

  it("trims entry text and rejects blank identifiers", () => {
    const normalized = normalizeHealthEntries([{ id: "  entry-1  ", date: "2026-08-19", symptoms: [{ name: "  Fatigue  ", severity: 3 }, { name: "   ", severity: 2 }], notes: "  personal note  " }, { id: "   ", date: "2026-08-18" }]);
    expect(normalized).toHaveLength(1);
    expect(normalized[0]).toMatchObject({ id: "entry-1", notes: "personal note", symptoms: [{ name: "Fatigue", severity: 3 }] });
  });
});

describe("retry-progress theme contrast", () => {
  it("keeps light and dark pill combinations above the normal-text contrast threshold", () => {
    expect(contrastRatio("#2F6B62", "#E8F3EF")).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio("#ECEDEE", "#1E2022")).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio("#11181C", "#F5F5F5")).toBeGreaterThanOrEqual(4.5);
    expect(retryProgressAccessibilityLayout()).toMatchObject({ maxWidth: "100%", flexShrink: 1, minHeight: 34, borderWidth: 2, lineHeight: 18, flexWrap: "wrap" });
    for (const language of languageOptions().map((option) => option.value)) {
      expect(translate(language, "journalRecoveryBody").trim().length).toBeGreaterThan(20);
      expect(translate(language, "hydrationRetryLimit").trim().length).toBeGreaterThan(20);
      expect(translate(language, "hydrationRetryProgress")).toContain("{attempt}");
      expect(translate(language, "hydrationRetryProgress")).toContain("{max}");
    }
  });
});

describe("hydration retry attempt bounds", () => {
  it("normalizes invalid attempt inputs safely", () => {
    expect(nextHydrationAttempt(-4)).toBe(1);
    expect(nextHydrationAttempt(Number.NaN)).toBe(1);
    expect(nextHydrationAttempt(Number.POSITIVE_INFINITY)).toBe(1);
    expect(canRetryHydrationAttempt(Number.NaN)).toBe(true);
    expect(canRetryHydrationAttempt(Number.POSITIVE_INFINITY)).toBe(true);
  });

  it("increments attempts, caps at the limit, and blocks after the cap", () => {
    expect(nextHydrationAttempt(0)).toBe(1);
    expect(nextHydrationAttempt(2)).toBe(HYDRATION_MAX_ATTEMPTS);
    expect(nextHydrationAttempt(HYDRATION_MAX_ATTEMPTS)).toBe(HYDRATION_MAX_ATTEMPTS);
    expect(canRetryHydrationAttempt(0)).toBe(true);
    expect(canRetryHydrationAttempt(HYDRATION_MAX_ATTEMPTS - 1)).toBe(true);
    expect(canRetryHydrationAttempt(HYDRATION_MAX_ATTEMPTS)).toBe(false);
    expect(translate("en", "hydrationRetryLimit")).toContain("Retry limit reached");
    expect(translate("es", "hydrationRetryLimit")).toContain("límite");
    expect(translate("zh", "hydrationRetryLimit")).toContain("重试上限");
    for (const language of languageOptions().map((option) => option.value)) {
      expect(translate(language, "hydrationRetryLimit")).toBeTruthy();
    }
    expect(translate("de", "hydrationRetryLimit")).not.toBe(translate("en", "hydrationRetryLimit"));
    expect(translate("ja", "hydrationRetryLimit")).not.toBe(translate("en", "hydrationRetryLimit"));
    const progress = translate("en", "hydrationRetryProgress").replace("{attempt}", "3").replace("{max}", "3");
    expect(progress).toBe("Retry attempt 3 of 3.");
    expect(translate("es", "hydrationRetryProgress")).toContain("{attempt}");
    for (const language of languageOptions().map((option) => option.value)) {
      const copy = translate(language, "hydrationRetryProgress");
      expect(copy).toContain("{attempt}");
      expect(copy).toContain("{max}");
    }
    expect(translate("de", "hydrationRetryProgress")).not.toBe(translate("en", "hydrationRetryProgress"));
    expect(translate("ja", "hydrationRetryProgress")).not.toBe(translate("en", "hydrationRetryProgress"));
  });
});

describe("hydration retry safety", () => {
  it("releases ownership after timeout rejection so a later retry can start", async () => {
    vi.useFakeTimers();
    try {
      let busyAction: string | null = null;
      const run = async () => {
        const claim = claimHydrationRetry(busyAction);
        if (!claim.accepted) return "blocked";
        busyAction = claim.nextBusyAction;
        try {
          await withTimeout(new Promise<void>(() => undefined), 10, HYDRATION_TIMEOUT_MESSAGE);
          return "resolved";
        } catch {
          return "rejected";
        } finally {
          busyAction = null;
        }
      };
      const first = run();
      await vi.advanceTimersByTimeAsync(10);
      expect(await first).toBe("rejected");
      expect(busyAction).toBeNull();
      const second = run();
      await vi.advanceTimersByTimeAsync(10);
      expect(await second).toBe("rejected");
      expect(busyAction).toBeNull();
    } finally {
      vi.useRealTimers();
    }
  });

  it("cancels a stalled hydration timeout without waiting for its timer", async () => {
    vi.useFakeTimers();
    try {
      const controller = new AbortController();
      const pending = withTimeout(new Promise<void>(() => undefined), 100, HYDRATION_TIMEOUT_MESSAGE, controller.signal);
      controller.abort();
      await expect(pending).rejects.toMatchObject({ name: "AbortError", message: "Operation cancelled" });
      await vi.advanceTimersByTimeAsync(100);
    } finally {
      vi.useRealTimers();
    }
  });

  it("observes a rejecting input promise when the signal was already aborted", async () => {
    const controller = new AbortController();
    controller.abort();
    const result = withTimeout(Promise.reject(new Error("input failed")), 100, HYDRATION_TIMEOUT_MESSAGE, controller.signal);
    await expect(result).rejects.toMatchObject({ name: "AbortError", message: "Operation cancelled" });
  });

  it("lets a promise settle when its exact-boundary timer was registered first", async () => {
    vi.useFakeTimers();
    try {
      const onTime = new Promise<string>((resolve) => { setTimeout(() => resolve("on-time"), 10); });
      const result = withTimeout(onTime, 10, HYDRATION_TIMEOUT_MESSAGE);
      await vi.advanceTimersByTimeAsync(10);
      await expect(result).resolves.toBe("on-time");
    } finally {
      vi.useRealTimers();
    }
  });

  it("keeps timeout ownership when the promise has not settled at the exact boundary", async () => {
    vi.useFakeTimers();
    try {
      let resolvePending!: (value: string) => void;
      const pending = new Promise<string>((resolve) => { resolvePending = resolve; });
      const result = withTimeout(pending, 10, HYDRATION_TIMEOUT_MESSAGE);
      const rejection = result.catch((error: unknown) => error);
      await vi.advanceTimersByTimeAsync(10);
      resolvePending("too-late");
      await expect(rejection).resolves.toMatchObject({ message: HYDRATION_TIMEOUT_MESSAGE });
    } finally {
      vi.useRealTimers();
    }
  });

  it("releases ownership after ordinary storage rejection and selects generic recovery copy", async () => {
    let busyAction: string | null = null;
    const claim = claimHydrationRetry(busyAction);
    expect(claim.accepted).toBe(true);
    busyAction = claim.nextBusyAction;
    try {
      await Promise.reject(new Error("mock storage read failure"));
    } catch (error) {
      expect((error as Error).message).toBe("mock storage read failure");
    } finally {
      busyAction = null;
    }
    expect(busyAction).toBeNull();
    const recoveryCopy = hydrationRecoveryViewModel(false, false);
    expect(recoveryCopy).toEqual({ titleKey: "journalLoadFailed", bodyKey: "journalRecoveryBody", retryKey: "retryLoading", retrying: false, titleAccessibilityRole: "header", focusOrder: ["title", "progress", "body", "retry"] });
    expect(translate("de", recoveryCopy.titleKey)).toContain("Journal");
    expect(translate("de", recoveryCopy.bodyKey)).toContain("keine Änderungen");
    expect(translate("de", hydrationRecoveryViewModel(false, true).retryKey)).toContain("Lokales Lesen");
    expect(claimHydrationRetry(busyAction).accepted).toBe(true);
  });

  it("rejects a concurrent request while the first stalled retry owns the slot", async () => {
    let busyAction: string | null = null;
    let release!: () => void;
    const stalled = new Promise<void>((resolve) => { release = resolve; });
    const request = async () => {
      const claim = claimHydrationRetry(busyAction);
      if (!claim.accepted) return false;
      busyAction = claim.nextBusyAction;
      await stalled;
      busyAction = null;
      return true;
    };
    const first = request();
    const second = request();
    expect(await second).toBe(false);
    release();
    expect(await first).toBe(true);
    expect(busyAction).toBeNull();
  });

  it("blocks overlapping hydration while allowing a fresh retry after cleanup", () => {
    expect(canStartHydrationRetry("hydrate")).toBe(false);
    expect(canStartHydrationRetry(null)).toBe(true);
    expect(canStartHydrationRetry("save")).toBe(true);
    expect(claimHydrationRetry(null)).toEqual({ accepted: true, nextBusyAction: "hydrate" });
    expect(claimHydrationRetry("hydrate")).toEqual({ accepted: false, nextBusyAction: "hydrate" });
    expect(claimHydrationRetry(null)).toEqual({ accepted: true, nextBusyAction: "hydrate" });
  });
});

describe("Simplified Chinese wording quality", () => {
  it("uses consistent privacy and local-recovery terminology", () => {
    expect(translate("zh", "continuePrivately")).toBe("在隐私保护下继续");
    expect(translate("zh", "privacyBody")).toContain("不会进行诊断或开具处方");
    expect(translate("zh", "journalRecoveryBody")).toContain("从本地读取");
    expect(translate("zh", "journalRecoveryBody")).toContain("支持团队");
    expect(translate("zh", "hydrationRetryLimit")).toContain("未被修改");
    expect(translate("zh", "privateNotes")).toBe("您的笔记仅供您查看。");
  });

  it("keeps Chinese backup and notice-status labels explicit", () => {
    expect(translate("zh", "localRestoreStatusTitle")).toBe("本地恢复记录状态");
    expect(translate("zh", "localRestoreRecorded")).toContain("已记录");
    expect(translate("zh", "localRestoreMissing")).toContain("尚无");
    expect(translateNoticeTiming("zh", "preview")).toContain("选择的时长");
    expect(translateNoticeTiming("zh", "hydrationWarning")).toContain("安全默认设置");
  });

  it("uses consistent formal address in Chinese notice timing copy", () => {
    expect(translateNoticeTiming("zh", "body")).toContain("您将其关闭");
    expect(translateNoticeTiming("zh", "preview")).toBe("预览：此提示将按您选择的时长显示。");
    expect(translateNoticeTiming("zh", "hydrationRetrying")).toContain("提示时长");
    expect(translateNoticeTiming("zh", "hydrationRecovered")).toBe("已恢复提示时长设置。");
    expect(translateNoticeTiming("zh", "error")).toContain("无法保存提示设置");
  });

  it("uses explicit Chinese appointment and import actions", () => {
    expect(translate("zh", "prepareVisit")).toBe("准备本次就诊");
    expect(translate("zh", "reviewHistory")).toBe("查看日志记录");
    expect(translate("zh", "chooseWindow")).toContain("就诊时");
    expect(translate("zh", "draftQuestions")).toContain("拟定问题");
    expect(translate("zh", "undoRecentImport")).toBe("撤销最近导入的日志");
    expect(translate("zh", "undoingImport")).toBe("正在撤销导入…");
    expect(translate("zh", "importUndoExpired")).toContain("时间已过期");
    expect(translate("zh", "undoExpiredBody")).toContain("较早的快照");
  });

  it("keeps Chinese local-status and summary labels explicit", () => {
    expect(translate("zh", "localRecovery")).toBe("本地恢复选项");
    expect(translate("zh", "privacyStatus")).toBe("日志仅保存在本设备");
    expect(translate("zh", "history")).toBe("历史记录");
    expect(translate("zh", "sourceNotes")).toBe("参考笔记");
    expect(translate("zh", "saveEntry")).toBe("已保存到您的日志中");
  });

  it("keeps Chinese settings actions explicit", () => {
    expect(translate("zh", "preferences")).toBe("偏好设置");
    expect(translate("zh", "enableLock")).toBe("启用生物识别锁定");
    expect(translate("zh", "disableLock")).toBe("停用生物识别锁定");
    expect(translate("zh", "timeout")).toContain("自动锁定");
    expect(translate("zh", "doctorQuestionStyle")).toBe("医生提问风格");
    expect(translate("zh", "savePreferences")).toBe("保存偏好设置");
    expect(translate("zh", "savingPreferences")).toContain("偏好设置");
  });
});

describe("clear confirmation accessibility", () => {
  it("classifies local backup and restore status for the review action", () => {
    expect(backupStatusReview({ savedAt: "2026-08-20T00:00:00.000Z", restoredAt: null }, "backup")).toBe("backup-recorded");
    expect(backupStatusReview({ savedAt: null, restoredAt: null }, "backup")).toBe("backup-missing");
    expect(backupStatusReview({ savedAt: null, restoredAt: "2026-08-20T00:00:00.000Z" }, "restore")).toBe("restore-recorded");
    expect(backupStatusReview({ savedAt: null, restoredAt: null }, "restore")).toBe("restore-missing");
  });

  it("keeps native and RTL backup-status translations readable", () => {
    for (const language of ["es", "fr", "zh", "ar"] as const) {
      expect(translate(language, "reviewLocalStatus")).not.toBe(translate("en", "reviewLocalStatus"));
      expect(translate(language, "localBackupStatusTitle").length).toBeGreaterThan(4);
      expect(translate(language, "localRestoreStatusTitle").length).toBeGreaterThan(4);
      expect(translate(language, "localBackupMissing").trim()).not.toBe("");
      expect(translate(language, "localRestoreMissing").trim()).not.toBe("");
    }
    expect(translate("ar", "localBackupStatusTitle")).toMatch(/[\u0600-\u06ff]/);
    expect(translate("ar", "localRestoreMissing")).toMatch(/[\u0600-\u06ff]/);
  });

  it("keeps retry-cap guidance and dismissal labels available in every locale", () => {
    for (const option of languageOptions()) {
      expect(translate(option.value, "hydrationRetryLimit").trim()).not.toBe("");
      expect(translate(option.value, "auditWarningDismiss").trim()).not.toBe("");
      expect(translate(option.value, "reviewLocalStatus").trim()).not.toBe("");
      expect(translate(option.value, "localBackupStatusTitle").trim()).not.toBe("");
      expect(translate(option.value, "localRestoreStatusTitle").trim()).not.toBe("");
      expect(translate(option.value, "localBackupRecorded").trim()).not.toBe("");
      expect(translate(option.value, "localBackupMissing").trim()).not.toBe("");
      expect(translate(option.value, "localRestoreRecorded").trim()).not.toBe("");
      expect(translate(option.value, "localRestoreMissing").trim()).not.toBe("");
    }
  });

  it("shows recovery action only at the retry cap", () => {
    expect(retryCapReached(2)).toBe(false);
    expect(retryCapReached(3)).toBe(true);
    expect(retryCapReached(4, 4)).toBe(true);
  });

  it("normalizes invalid retry-cap inputs consistently", () => {
    expect(retryCapReached(Number.NaN, Number.POSITIVE_INFINITY)).toBe(false);
    expect(retryCapReached(-2, 0)).toBe(false);
    expect(retryCapReached(3.9, 4.8)).toBe(false);
    expect(retryCapReached(4.9, 4.8)).toBe(true);
  });

  it("keeps retry announcements and cap decisions on the same normalized boundary", () => {
    expect(retryAttemptProgress("Retry {attempt}/{max}", 9.8, 4.8)).toBe("Retry 4/4");
    expect(retryCapReached(9.8, 4.8)).toBe(true);
    expect(retryAttemptProgress("Retry {attempt}/{max}", Number.NaN, 0)).toBe("Retry 1/3");
    expect(retryCapReached(Number.NaN, 0)).toBe(false);
  });

  it.each([
    { attempt: 1, max: 3, progress: "Retry 1/3", capped: false },
    { attempt: 3, max: 3, progress: "Retry 3/3", capped: true },
    { attempt: -1, max: 2, progress: "Retry 1/2", capped: false },
    { attempt: Number.POSITIVE_INFINITY, max: 2, progress: "Retry 1/2", capped: false },
  ])("preserves the retry normalization contract for $attempt/$max", ({ attempt, max, progress, capped }) => {
    expect(retryAttemptProgress("Retry {attempt}/{max}", attempt, max)).toBe(progress);
    expect(retryCapReached(attempt, max)).toBe(capped);
  });

  it("formats and caps localized retry-attempt announcements", () => {
    expect(retryAttemptProgress("Retry attempt {attempt} of {max}", 1)).toBe("Retry attempt 1 of 3");
    expect(retryAttemptProgress("Retry attempt {attempt} of {max}", 5)).toBe("Retry attempt 3 of 3");
    expect(retryAttemptProgress("Wiederholung {attempt} von {max}", 2, 4)).toBe("Wiederholung 2 von 4");
  });

  it("normalizes invalid retry-progress inputs", () => {
    expect(retryAttemptProgress("Retry {attempt}/{max}", Number.NaN, Number.POSITIVE_INFINITY)).toBe("Retry 1/3");
    expect(retryAttemptProgress("Retry {attempt}/{max}", -4, 0)).toBe("Retry 1/3");
    expect(retryAttemptProgress("Retry {attempt}/{max}", 2.9, 4.8)).toBe("Retry 2/4");
  });

  it("selects stable retry targets for repeated backup and restore failures", () => {
    expect(retryFocusTargetFor("backup")).toBe("backup-retry");
    expect(retryFocusTargetFor("backup")).toBe("backup-retry");
    expect(retryFocusTargetFor("restore")).toBe("restore-retry");
    expect(retryFocusTargetFor("restore")).toBe("restore-retry");
  });

  it("returns focus to Settings after backup and restore outcomes", () => {
    expect(settingsOperationFocusTarget("backup-failed")).toBe("settings");
    expect(settingsOperationFocusTarget("backup-completed")).toBe("settings");
    expect(settingsOperationFocusTarget("restore-failed")).toBe("settings");
    expect(settingsOperationFocusTarget("restore-completed")).toBe("settings");
  });

  it("returns focus to Settings after cancellation, completion, or failure", () => {
    expect(clearConfirmationFocusTarget("cancelled")).toBe("settings");
    expect(clearConfirmationFocusTarget("cleared")).toBe("settings");
    expect(clearConfirmationFocusTarget("failed")).toBe("settings");
  });

  it("describes the number of entries that will be removed", () => {
    expect(clearConfirmationAccessibilityLabel(3)).toBe("Clear 3 saved journal entries");
    expect(clearConfirmationAccessibilityLabel(0)).toBe("Clear saved journal data");
  });
});

describe("feedback accessibility policy", () => {
  it("uses assertive announcements only for persistent recovery notices", () => {
    expect(noticeLiveRegionFor(false)).toBe("polite");
    expect(noticeLiveRegionFor(true)).toBe("assertive");
  });
});

describe("modal accessibility transitions", () => {
  it("identifies open and close transitions without treating steady state as focus work", () => {
    expect(modalFocusTransition(false, true)).toBe("open");
    expect(modalFocusTransition(true, false)).toBe("close");
    expect(modalFocusTransition(false, false)).toBe("unchanged");
    expect(modalFocusTransition(true, true)).toBe("unchanged");
    expect(shouldApplyModalFocusRequest(2, 2, "close")).toBe(true);
    expect(shouldApplyModalFocusRequest(1, 2, "close")).toBe(false);
    expect(shouldApplyModalFocusRequest(2, 2, "open")).toBe(false);
    expect(resolveModalFocusTargetId("premium", ["settings", "premium"])).toBe("premium");
    expect(resolveModalFocusTargetId("missing", ["settings", "premium"])).toBeNull();
    expect(resolveModalFocusTargetId(null, ["settings", "premium"])).toBeNull();
  });
});

describe("semantic heading accessibility contract", () => {
  it("uses the native header role consistently", () => {
    expect(ACCESSIBILITY_HEADING_ROLE).toBe("header");
    expect(hydrationRecoveryViewModel(false, false).titleAccessibilityRole).toBe(ACCESSIBILITY_HEADING_ROLE);
  });
});

describe("hydration recovery render model", () => {
  it("selects timeout copy across representative locales and active retry state", () => {
    const timeoutCopy = hydrationRecoveryViewModel(true, false);
    const activeRetryCopy = hydrationRecoveryViewModel(true, true);
    for (const language of ["en", "es", "zh", "de", "ja", "ru"] as const) {
      expect(translate(language, timeoutCopy.titleKey)).toBeTruthy();
      expect(translate(language, timeoutCopy.bodyKey)).toBeTruthy();
      expect(translate(language, activeRetryCopy.retryKey)).toBeTruthy();
    }
    expect(translate("en", timeoutCopy.titleKey)).toContain("timed out");
    expect(translate("es", timeoutCopy.titleKey)).toContain("agotó");
    expect(translate("zh", timeoutCopy.titleKey)).toContain("超时");
    expect(activeRetryCopy.retrying).toBe(true);
    expect(timeoutCopy.titleAccessibilityRole).toBe("header");
    expect(timeoutCopy.focusOrder[0]).toBe("title");
  });

  it("selects timeout copy and idle retry state", () => {
    expect(hydrationRecoveryViewModel(true, false)).toEqual({ titleKey: "journalLoadTimeoutTitle", bodyKey: "journalLoadTimeout", retryKey: "retryLoading", retrying: false, titleAccessibilityRole: "header", focusOrder: ["title", "progress", "body", "retry"] });
  });

  it("selects generic copy and busy retry accessibility state", () => {
    expect(hydrationRecoveryViewModel(false, true)).toEqual({ titleKey: "journalLoadFailed", bodyKey: "journalRecoveryBody", retryKey: "retryLoadingProgress", retrying: true, titleAccessibilityRole: "header", focusOrder: ["title", "progress", "body", "retry"] });
  });
});

describe("hydration timeout safety", () => {
  it("classifies only the bounded hydration timeout error", () => {
    expect(isHydrationTimeoutError(new Error(HYDRATION_TIMEOUT_MESSAGE))).toBe(true);
    expect(isHydrationTimeoutError(new Error("other local read failure"))).toBe(false);
    expect(isHydrationTimeoutError("Local journal loading timed out")).toBe(false);
  });
  it("rejects a stalled local read at the bounded timeout", async () => {
    vi.useFakeTimers();
    try {
      const stalled = new Promise<string>(() => undefined);
      const pending = withTimeout(stalled, HYDRATION_TIMEOUT_MS, "hydration timeout");
      const assertion = expect(pending).rejects.toThrow("hydration timeout");
      vi.advanceTimersByTime(HYDRATION_TIMEOUT_MS - 1);
      await Promise.resolve();
      vi.advanceTimersByTime(1);
      await assertion;
    } finally {
      vi.useRealTimers();
    }
  });

  it("normalizes invalid timeout durations to an immediate rejection", async () => {
    vi.useFakeTimers();
    try {
      const stalled = new Promise<string>(() => undefined);
      const negative = withTimeout(stalled, -1, "invalid timeout");
      const infinite = withTimeout(stalled, Number.NaN, "invalid timeout");
      const negativeAssertion = expect(negative).rejects.toThrow("invalid timeout");
      const infiniteAssertion = expect(infinite).rejects.toThrow("invalid timeout");
      vi.advanceTimersByTime(0);
      await negativeAssertion;
      await infiniteAssertion;
    } finally {
      vi.useRealTimers();
    }
  });

  it("resolves promptly and clears its timer when hydration completes", async () => {
    vi.useFakeTimers();
    try {
      const pending = withTimeout(Promise.resolve("ready"), HYDRATION_TIMEOUT_MS, "hydration timeout");
      await expect(pending).resolves.toBe("ready");
      vi.advanceTimersByTime(HYDRATION_TIMEOUT_MS);
    } finally {
      vi.useRealTimers();
    }
  });
});

describe("notice preview lifecycle", () => {
  it("auto-clears timed previews only at their configured duration", () => {
    vi.useFakeTimers();
    const clear = vi.fn();
    const sixSecondTimer = scheduleRoutineNoticeClear(6000, clear);
    expect(sixSecondTimer).not.toBeNull();
    vi.advanceTimersByTime(5999);
    expect(clear).not.toHaveBeenCalled();
    vi.advanceTimersByTime(1);
    expect(clear).toHaveBeenCalledTimes(1);
    clear.mockClear();
    const twelveSecondTimer = scheduleRoutineNoticeClear(12000, clear);
    expect(twelveSecondTimer).not.toBeNull();
    vi.advanceTimersByTime(11999);
    expect(clear).not.toHaveBeenCalled();
    vi.advanceTimersByTime(1);
    expect(clear).toHaveBeenCalledTimes(1);
    vi.useRealTimers();
  });

  it("clears bounded dismissal feedback after the configured success interval", () => {
    vi.useFakeTimers();
    const opened = reduceNoticePreviewState({ visible: false, dismissed: false }, "open");
    const dismissed = reduceNoticePreviewState(opened, "dismiss");
    expect(dismissed.dismissed).toBe(true);
    vi.advanceTimersByTime(NOTICE_TIMING_SUCCESS_FEEDBACK_MS - 1);
    expect(dismissed.dismissed).toBe(true);
    vi.advanceTimersByTime(1);
    expect(reduceNoticePreviewState(dismissed, "auto_clear").dismissed).toBe(true);
    vi.useRealTimers();
  });

  it("clears stale dismissal feedback when reopening a Persistent preview", () => {
    const opened = reduceNoticePreviewState({ visible: false, dismissed: true }, "open");
    expect(opened).toEqual({ visible: true, dismissed: false });
    const dismissed = reduceNoticePreviewState(opened, "dismiss");
    expect(dismissed).toEqual({ visible: false, dismissed: true });
    expect(reduceNoticePreviewState(dismissed, "auto_clear")).toEqual({ visible: false, dismissed: true });
    expect(reduceNoticePreviewState(dismissed, "open")).toEqual({ visible: true, dismissed: false });
  });
});

describe("notice timing active-label derivation", () => {
  it("maps each timing mode to its matching localized copy key", () => {
    expect(noticeTimingCopyKeyFor(6000)).toBe("sixSeconds");
    expect(noticeTimingCopyKeyFor(12000)).toBe("twelveSeconds");
    expect(noticeTimingCopyKeyFor("persistent")).toBe("persistent");
    expect(translateNoticeTiming("es", noticeTimingCopyKeyFor(6000))).toBe("6 segundos");
    expect(translateNoticeTiming("zh", noticeTimingCopyKeyFor(12000))).toBe("12 秒");
    expect(translateNoticeTiming("en", noticeTimingCopyKeyFor("persistent"))).toBe("Persistent");
    const selections = [6000, 12000, "persistent"] as const;
    expect(selections.map(noticeTimingCopyKeyFor)).toEqual(["sixSeconds", "twelveSeconds", "persistent"]);
  });
});

describe("notice timing localization", () => {
  it("provides complete accessible copy for every supported language", () => {
    for (const option of languageOptions()) {
      expect(translateNoticeTiming(option.value, "title")).toBeTruthy();
      expect(translate(option.value, "journalLoadTimeoutTitle")).toBeTruthy();
      expect(translate(option.value, "journalLoadTimeout")).toBeTruthy();
      expect(translate(option.value, "retryLoadingProgress")).toBeTruthy();
      expect(translate(option.value, "journalRecoveryBody")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "body")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "sixSeconds")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "twelveSeconds")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "persistent")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "saving")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "saved")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "error")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "retry")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "retrying")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "hydrationWarning")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "hydrationRetry")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "hydrationRetrying")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "hydrationRecovered")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "preview")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "dismissPreview")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "activeTiming")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "expired")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "sixSeconds")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "twelveSeconds")).toBeTruthy();
      expect(translateNoticeTiming(option.value, "persistent")).toBeTruthy();
    }
    expect(translateNoticeTiming("es", "sixSeconds")).toBe("6 segundos");
    expect(translateNoticeTiming("zh", "persistent")).toBe("持续显示");
    expect(translateNoticeTiming("fr", "error")).toContain("enregistrée");
    expect(translate("en", "journalLoadTimeoutTitle")).toBe("Local journal loading timed out");
    expect(translate("en", "journalLoadTimeout")).toContain("Local loading");
    expect(translate("en", "retryLoadingProgress")).toContain("Retrying");
    expect(translate("en", "journalRecoveryBody")).toContain("No new changes");
    expect(translate("es", "journalRecoveryBody")).toContain("No se hicieron cambios");
    expect(translate("es", "journalLoadTimeout")).toContain("carga local");
    expect(translate("zh", "journalLoadTimeoutTitle")).toBe("本地日志加载超时");
    expect(translate("zh", "journalLoadTimeout")).toContain("本地加载");
    expect(translate("zh", "retryLoadingProgress")).toContain("重试");
    expect(translate("de", "journalLoadTimeoutTitle")).toContain("Zeitüberschreitung");
    expect(translate("ja", "retryLoadingProgress")).toContain("再試行");
    expect(translate("ru", "journalRecoveryBody")).toContain("Изменения");
    expect(translateNoticeTiming("es", "retry")).toBe("Reintentar guardado");
    expect(translateNoticeTiming("zh", "retrying")).toContain("重试");
    expect(translateNoticeTiming("en", "hydrationRetry")).toBe("Try reading again");
    expect(translateNoticeTiming("es", "hydrationRecovered")).toContain("restauró");
    expect(translateNoticeTiming("en", "preview")).toContain("Preview");
    expect(`${translateNoticeTiming("en", "preview")} · ${translateNoticeTiming("en", noticeTimingCopyKeyFor(6000))}`).toContain("6 seconds");
    expect(translateNoticeTiming("en", "dismissPreview")).toBe("Dismiss preview");
    expect(translateNoticeTiming("ja", "dismissPreview")).toBe("プレビューを閉じる");
    expect(translateNoticeTiming("en", "persistent")).toBe("Persistent");
    expect(translateNoticeTiming("en", "activeTiming")).toBe("Active timing");
    expect(translateNoticeTiming("en", "expired")).toBe("Preview ended.");
    expect(translateNoticeTiming("zh", "expired")).toBe("预览已结束。");
    expect(`${translateNoticeTiming("en", "saved")} · ${translateNoticeTiming("en", noticeTimingCopyKeyFor(12000))}`).toContain("12 seconds");
    expect(`${translateNoticeTiming("es", "saving")} · ${translateNoticeTiming("es", noticeTimingCopyKeyFor(6000))}`).toContain("6 segundos");
    expect(noticeTimingFeedback("en", "saving", noticeTimingCopyKeyFor("persistent"))).toContain("Persistent");
    expect(noticeTimingFeedback("fr", "saved", noticeTimingCopyKeyFor(12000))).toContain("12 secondes");
  });
});

describe("notice timing success feedback", () => {
  it("announces expiration exactly when a timed preview clears", () => {
    vi.useFakeTimers();
    try {
      const expired = vi.fn();
      scheduleRoutineNoticeClear(6000, expired);
      vi.advanceTimersByTime(5999);
      expect(expired).not.toHaveBeenCalled();
      vi.advanceTimersByTime(1);
      expect(expired).toHaveBeenCalledTimes(1);
      expect(translateNoticeTiming("es", "expired")).toBe("La vista previa terminó.");
    } finally {
      vi.useRealTimers();
    }
  });

  it("uses the same lifecycle contract for the Settings preview", () => {
    vi.useFakeTimers();
    try {
      const sixSecondPreview = vi.fn();
      scheduleRoutineNoticeClear(6000, sixSecondPreview);
      vi.advanceTimersByTime(6000);
      expect(sixSecondPreview).toHaveBeenCalledTimes(1);

      const twelveSecondPreview = vi.fn();
      scheduleRoutineNoticeClear(12000, twelveSecondPreview);
      vi.advanceTimersByTime(11999);
      expect(twelveSecondPreview).not.toHaveBeenCalled();
      vi.advanceTimersByTime(1);
      expect(twelveSecondPreview).toHaveBeenCalledTimes(1);

      const persistentPreview = vi.fn();
      expect(scheduleRoutineNoticeClear("persistent", persistentPreview)).toBeNull();
      vi.runAllTimers();
      expect(persistentPreview).not.toHaveBeenCalled();
    } finally {
      vi.useRealTimers();
    }
  });

  it("respects each configurable routine notice mode", () => {
    vi.useFakeTimers();
    try {
      const shortClear = vi.fn();
      scheduleRoutineNoticeClear(6000, shortClear);
      vi.advanceTimersByTime(5999);
      expect(shortClear).not.toHaveBeenCalled();
      vi.advanceTimersByTime(1);
      expect(shortClear).toHaveBeenCalledTimes(1);

      const longClear = vi.fn();
      scheduleRoutineNoticeClear(12000, longClear);
      vi.advanceTimersByTime(11999);
      expect(longClear).not.toHaveBeenCalled();
      vi.advanceTimersByTime(1);
      expect(longClear).toHaveBeenCalledTimes(1);

      const persistentClear = vi.fn();
      expect(scheduleRoutineNoticeClear("persistent", persistentClear)).toBeNull();
      vi.runAllTimers();
      expect(persistentClear).not.toHaveBeenCalled();
    } finally {
      vi.useRealTimers();
    }
  });
  it("does not invoke a preview callback after its timer is cleaned up", () => {
    vi.useFakeTimers();
    try {
      const callback = vi.fn();
      const timer = scheduleRoutineNoticeClear(6000, callback);
      expect(timer).not.toBeNull();
      if (timer) clearTimeout(timer);
      vi.advanceTimersByTime(6000);
      expect(callback).not.toHaveBeenCalled();
    } finally {
      vi.useRealTimers();
    }
  });

  it("clears expiration feedback exactly at the shared bounded delay", () => {
    vi.useFakeTimers();
    try {
      const clearExpiration = vi.fn();
      scheduleNoticeTimingSuccessClear(clearExpiration);
      vi.advanceTimersByTime(NOTICE_TIMING_SUCCESS_FEEDBACK_MS - 1);
      expect(clearExpiration).not.toHaveBeenCalled();
      vi.advanceTimersByTime(1);
      expect(clearExpiration).toHaveBeenCalledTimes(1);
    } finally {
      vi.useRealTimers();
    }
  });

  it("clears hydration-recovery success feedback exactly at the bounded delay", () => {
    vi.useFakeTimers();
    try {
      const clearRecovery = vi.fn();
      scheduleNoticeTimingSuccessClear(clearRecovery);
      vi.advanceTimersByTime(3999);
      expect(clearRecovery).not.toHaveBeenCalled();
      vi.advanceTimersByTime(1);
      expect(clearRecovery).toHaveBeenCalledTimes(1);
    } finally {
      vi.useRealTimers();
    }
  });

  it("clears success feedback exactly at the bounded delay", () => {
    vi.useFakeTimers();
    try {
      const onClear = vi.fn();
      scheduleNoticeTimingSuccessClear(onClear);
      vi.advanceTimersByTime(NOTICE_TIMING_SUCCESS_FEEDBACK_MS - 1);
      expect(onClear).not.toHaveBeenCalled();
      vi.advanceTimersByTime(1);
      expect(onClear).toHaveBeenCalledTimes(1);
    } finally {
      vi.useRealTimers();
    }
  });
});

describe("notice timing persistence recovery", () => {
  beforeEach(() => { mockStorage.data.clear(); mockStorage.failWrites = false; mockStorage.failReads = false; });

  it("blocks duplicate hydration retries while a read is active or another operation is busy", () => {
    expect(canRetryNoticeTimingHydration(true, false)).toBe(false);
    expect(canRetryNoticeTimingHydration(false, true)).toBe(false);
    expect(canRetryNoticeTimingHydration(false, false)).toBe(true);
  });

  it("recovers from an unavailable read on a later retry without changing journal data", async () => {
    mockStorage.failReads = true;
    await expect(loadNoticeTimingWithStatus()).resolves.toEqual({ value: defaultNoticeTiming, recovered: true });
    mockStorage.failReads = false;
    mockStorage.data.set("ai-health-journal.notice-timing.v1", JSON.stringify(12000));
    await expect(loadNoticeTimingWithStatus()).resolves.toEqual({ value: 12000, recovered: false });
    expect(mockStorage.data.has("journal-entries")).toBe(false);
  });

  it("reports a recovered fallback when storage is unavailable", async () => {
    mockStorage.failReads = true;
    await expect(loadNoticeTimingWithStatus()).resolves.toEqual({ value: defaultNoticeTiming, recovered: true });
  });

  it("reports a recovered fallback when storage is malformed", async () => {
    mockStorage.data.set("ai-health-journal.notice-timing.v1", JSON.stringify("bad-value"));
    await expect(loadNoticeTimingWithStatus()).resolves.toEqual({ value: defaultNoticeTiming, recovered: true });
  });

  it("reports a normal hydration for a valid stored preference", async () => {
    mockStorage.data.set("ai-health-journal.notice-timing.v1", JSON.stringify(12000));
    await expect(loadNoticeTimingWithStatus()).resolves.toEqual({ value: 12000, recovered: false });
  });

  it("falls back to the default when storage is unavailable", async () => {
    mockStorage.failReads = true;
    await expect(loadNoticeTiming()).resolves.toBe(defaultNoticeTiming);
  });

  it("falls back to the default when storage is malformed", async () => {
    mockStorage.data.set("ai-health-journal.notice-timing.v1", JSON.stringify("bad-value"));
    await expect(loadNoticeTiming()).resolves.toBe(defaultNoticeTiming);
  });

  it("keeps the active setting after a failed write and recovers on retry", async () => {
    mockStorage.failWrites = true;
    await expect(saveNoticeTiming(12000)).rejects.toThrow("mock storage write failure");
    expect(await loadNoticeTiming()).toBe(defaultNoticeTiming);
    mockStorage.failWrites = false;
    await expect(saveNoticeTiming(12000)).resolves.toBeUndefined();
    await expect(loadNoticeTiming()).resolves.toBe(12000);
    mockStorage.failReads = true;
    await expect(loadNoticeTiming()).resolves.toBe(defaultNoticeTiming);
  });

  it("normalizes malformed notice timing before persistence", async () => {
    await saveNoticeTiming("invalid" as unknown as NoticeTiming);
    expect(mockStorage.data.get("ai-health-journal.notice-timing.v1")).toBe(JSON.stringify(defaultNoticeTiming));
    await expect(loadNoticeTiming()).resolves.toBe(defaultNoticeTiming);
  });
});

describe("notice timing safety", () => {
  it("accepts the supported timing values and falls back safely for malformed data", () => {
    expect(normalizeNoticeTiming(6000)).toBe(6000);
    expect(normalizeNoticeTiming(12000)).toBe(12000);
    expect(normalizeNoticeTiming("persistent")).toBe("persistent");
    expect(normalizeNoticeTiming(0)).toBe(defaultNoticeTiming);
    expect(normalizeNoticeTiming({ duration: 6000 })).toBe(defaultNoticeTiming);
    expect(canChangeNoticeTiming(6000, 12000, false)).toBe(true);
    expect(canChangeNoticeTiming(6000, 6000, false)).toBe(false);
    expect(canChangeNoticeTiming(6000, 12000, true)).toBe(false);
  });
});

describe("backup metadata safety", () => {
  it("drops malformed timestamps without losing valid backup metadata", () => {
    expect(normalizeBackupStatus({ savedAt: "not-a-date", restoredAt: "2026-08-19T12:00:00.000Z" })).toEqual({ savedAt: null, restoredAt: "2026-08-19T12:00:00.000Z" });
  });

  it("normalizes malformed backup metadata before persistence", async () => {
    await saveBackupStatus({ savedAt: "not-a-date" as unknown as string, restoredAt: "2026-08-19T12:00:00.000Z" });
    expect(mockStorage.data.get("ai-health-journal.backup.status.v1")).toBe(JSON.stringify({ savedAt: null, restoredAt: "2026-08-19T12:00:00.000Z" }));
  });
});

describe("local activity safety", () => {
  it("filters invalid events, orders newest first, and keeps a bounded timeline", () => {
    const events = Array.from({ length: 24 }, (_, index) => ({ id: `event-${index}`, type: "journal_saved" as const, occurredAt: `2026-08-${String(index + 1).padStart(2, "0")}T12:00:00.000Z`, detail: "ok" }));
    const normalized = normalizeLocalActivity([{ id: "bad", type: "unknown", occurredAt: "not-a-date" }, ...events]);
    expect(normalized).toHaveLength(20);
    expect(normalized[0].id).toBe("event-23");
    expect(normalized.every((event) => event.type === "journal_saved")).toBe(true);
    expect(normalizeLocalActivity([{ id: "detail", type: "journal_saved", occurredAt: "2026-08-19T12:00:00.000Z", detail: "  saved  " }, { id: "empty-detail", type: "journal_saved", occurredAt: "2026-08-19T12:01:00.000Z", detail: "   " }])).toEqual([{ id: "empty-detail", type: "journal_saved", occurredAt: "2026-08-19T12:01:00.000Z", detail: undefined }, { id: "detail", type: "journal_saved", occurredAt: "2026-08-19T12:00:00.000Z", detail: "saved" }]);
    expect(normalizeLocalActivity([{ id: "same", type: "import_completed", occurredAt: "2026-08-19T12:00:00.000Z" }, { id: "same", type: "import_undone", occurredAt: "2026-08-19T12:01:00.000Z" }, { id: "expired", type: "import_undo_expired", occurredAt: "2026-08-19T12:02:00.000Z" }]).map((event) => event.id)).toEqual(["expired", "same"]);
    expect(normalizeLocalActivity([{ id: "  trimmed  ", type: "journal_saved", occurredAt: "2026-08-19T12:00:00.000Z" }, { id: "   ", type: "journal_saved", occurredAt: "2026-08-19T12:01:00.000Z" }]).map((event) => event.id)).toEqual(["trimmed"]);
  });

  it("appends a valid event without mutating the prior timeline", () => {
    const prior = normalizeLocalActivity([{ id: "old", type: "backup_saved", occurredAt: "2026-08-01T12:00:00.000Z" }]);
    const next = appendLocalActivity(prior, { id: "new", type: "backup_restored", occurredAt: "2026-08-02T12:00:00.000Z", detail: "3 entries" });
    expect(prior).toHaveLength(1);
    expect(next.map((event) => event.id)).toEqual(["new", "old"]);
  });
});

describe("health journal summaries", () => {
  it("returns personal observations without diagnostic claims", () => {
    const result = summarize(entries);
    expect(result[0].title).toContain("Average sleep");
    expect(result.some((item) => item.title.includes("Fatigue appeared 3 times"))).toBe(true);
    expect(result.every((item) => !/diagnos|prescrib|treatment/i.test(`${item.title} ${item.detail}`))).toBe(true);
  });

  it("returns no insights when there is no journal data", () => {
    expect(summarize([])).toEqual([]);
  });

  it("aggregates neutral trend summaries from recent entries", () => {
    const trend = trendSummary(entries);
    expect(trend.days).toBe(3);
    expect(trend.averageSleep).toBeCloseTo(5.83, 1);
    expect(trend.topSymptoms[0]).toEqual(["Fatigue", 3]);
  });

  it("updates only the matching entry", () => {
    const updated = updateEntry(entries, { ...entries[1], notes: "Updated note" });
    expect(updated[1].notes).toBe("Updated note");
    expect(updated[0].notes).toBe("");
  });

  it("generates reflection prompts instead of medical recommendations", () => {
    const prompts = reflectionPrompts({ ...defaultPreferences, focus: "sleep" }, entries);
    expect(prompts.length).toBeGreaterThan(0);
    expect(prompts.join(" ")).not.toMatch(/diagnos|prescrib|treatment|risk score/i);
  });

  it("round-trips a user-controlled journal export", () => {
    const restored = parseJournalExport(serializeJournal(entries));
    expect(restored).toEqual(entries);
  });

  it("reports skipped records while importing a partially valid export", () => {
    const report = parseJournalExportWithReport(JSON.stringify({ version: 2, entries: [{ id: "one", date: "2026-08-19", mood: 3 }, { id: "one", date: "2026-08-18", mood: 2 }, { id: "two", date: "bad", mood: 4 }] }));
    expect(report.entries).toHaveLength(1);
    expect(report.discardedCount).toBe(2);
  });

  it("previews import metadata without exposing journal content", () => {
    const preview = previewJournalImport(JSON.stringify({ version: 2, entries }));
    expect(preview).toEqual({ version: 2, entryCount: 3, skippedCount: 0, firstDate: "2026-08-16", lastDate: "2026-08-18" });
  });

  it("creates a bounded undo snapshot and expires it deterministically", async () => {
    const snapshot = createJournalUndoSnapshot([...entries, ...entries], "2026-08-19T12:00:00.000Z");
    expect(snapshot.entries).toHaveLength(3);
    expect(journalUndoAgeMs(snapshot, Date.parse("2026-08-19T12:05:00.000Z"))).toBe(5 * 60 * 1000);
    expect(canUndoJournalImport(snapshot, Date.parse("2026-08-19T12:09:59.000Z"))).toBe(true);
    expect(canUndoJournalImport(snapshot, Date.parse("2026-08-19T12:10:01.000Z"))).toBe(false);
    expect(canUndoJournalImport(snapshot, Date.parse("2026-08-19T11:59:59.000Z"))).toBe(false);
    expect(canUndoJournalImport(snapshot, Date.parse("2026-08-19T12:05:00.000Z"), Number.POSITIVE_INFINITY)).toBe(false);
    expect(canUndoJournalImport(snapshot, Date.parse("2026-08-19T12:05:00.000Z"), -1)).toBe(false);
    expect(canUndoJournalImport(null)).toBe(false);
    expect(canApplyJournalUndo(snapshot, entries, entries)).toBe(false);
    expect(canApplyJournalUndo(snapshot, entries, snapshot.entries, Date.parse("2026-08-19T12:01:00.000Z"))).toBe(true);
    expect(canApplyJournalUndo(snapshot, entries, [...entries, { id: "new", date: "2026-08-19", mood: 4, sleepHours: 7, activityMinutes: 0, symptoms: [], notes: "" }])).toBe(false);
    expect(normalizeJournalUndoSnapshot({ createdAt: "bad", entries })).toBeNull();
    expect(invalidateJournalUndoSnapshot()).toBeNull();
    const calls: string[] = [];
    await expect(replaceJournalDataset(entries, async () => { calls.push("clear"); throw new Error("clear failed"); }, async () => { calls.push("save"); })).rejects.toThrow("clear failed");
    expect(calls).toEqual(["save", "clear"]);
    calls.length = 0;
    await expect(replaceJournalDataset(entries, async () => { calls.push("clear"); }, async () => { calls.push("save"); throw new Error("save failed"); })).rejects.toThrow("save failed");
    expect(calls).toEqual(["save"]);
    await expect(persistLocalActivityBestEffort([], async () => { throw new Error("activity failed"); })).resolves.toBe(false);
    await expect(persistLocalActivityBestEffort([], async () => undefined)).resolves.toBe(true);
    expect(normalizeJournalUndoSnapshot({ createdAt: "2026-08-19T12:00:00.000Z", entries: [{ id: "ok", date: "2026-08-19", mood: 4 }] })).toMatchObject({ createdAt: "2026-08-19T12:00:00.000Z", entries: [{ id: "ok", date: "2026-08-19" }] });
  });

  it("rejects malformed journal exports", () => {
    expect(parseJournalExport(JSON.stringify({ version: 2, entries: [] }))).toEqual([]);
    expect(() => parseJournalExport(JSON.stringify({ version: 1, entries: [{ id: "bad" }] }))).toThrow("Invalid journal entries");
    expect(() => parseJournalExport(JSON.stringify({ version: 2, entries: [{ id: "bad" }] }))).toThrow("Invalid journal entries");
  });

  it("keeps onboarding acceptance and clear confirmation deterministic", () => {
    expect(isOnboardingAccepted("accepted")).toBe(true);
    expect(isOnboardingAccepted(null)).toBe(false);
    expect(shouldConfirmClear(0)).toBe(false);
    expect(shouldConfirmClear(entries.length)).toBe(true);
    expect(normalizeSecurityPreferences({ biometricLock: true })).toEqual({ biometricLock: true, lockTimeoutSeconds: 300 });
    expect(normalizeSecurityPreferences({ biometricLock: "yes" })).toEqual({ biometricLock: false, lockTimeoutSeconds: 300 });
    expect(normalizeSecurityPreferences(null)).toEqual({ biometricLock: false, lockTimeoutSeconds: 300 });
    expect(normalizeSecurityPreferences({ biometricLock: true, lockTimeoutSeconds: 60 })).toEqual({ biometricLock: true, lockTimeoutSeconds: 60 });
    expect(normalizeSecurityPreferences({ biometricLock: true, lockTimeoutSeconds: 45 })).toEqual({ biometricLock: true, lockTimeoutSeconds: 300 });
  });

  it("normalizes malformed security preferences before persistence", async () => {
    await saveSecurityPreferences({ biometricLock: "yes" as unknown as boolean, lockTimeoutSeconds: 45 as unknown as SecurityPreferences["lockTimeoutSeconds"] });
    expect(mockStorage.data.get("ai-health-journal.security.v1")).toBe(JSON.stringify({ biometricLock: false, lockTimeoutSeconds: 300 }));
  });

  it("normalizes malformed journal preferences before persistence", async () => {
    expect(normalizeJournalPreferences({ focus: "unknown", cadence: "sometimes", promptStyle: "bad", questionStyle: "bad" })).toEqual(defaultPreferences);
    await savePreferences({ focus: "unknown" as never, cadence: "sometimes" as never, promptStyle: "bad" as never, questionStyle: "bad" as never });
    expect(mockStorage.data.get("ai-health-journal.preferences.v1")).toBe(JSON.stringify(defaultPreferences));
  });

  it("normalizes malformed preparation preferences before persistence", async () => {
    expect(normalizePrepPreferences({ rangeDays: 90, questions: [" Keep this ", "   ", 42, null] })).toEqual({ rangeDays: 14, questions: ["Keep this"], context: { onset: "", duration: "", triggers: "", impact: "" } });
    expect(normalizePrepPreferences({ questions: ["x".repeat(300)], context: { onset: "  Monday  ", duration: "x".repeat(300), triggers: 42 } }).context).toEqual({ onset: "Monday", duration: "x".repeat(240), triggers: "", impact: "" });
    expect(normalizeClinicianContext({ onset: "  last week ", duration: null, triggers: " stress ", impact: "x".repeat(300) })).toEqual({ onset: "last week", duration: "", triggers: "stress", impact: "x".repeat(240) });
    await savePrepPreferences({ rangeDays: 90 as never, questions: ["Keep this", 42 as never], context: { onset: "", duration: "", triggers: "", impact: "" } });
    expect(mockStorage.data.get("ai-health-journal.prep.v1")).toBe(JSON.stringify({ rangeDays: 14, questions: ["Keep this"], context: { onset: "", duration: "", triggers: "", impact: "" } }));
  });

  it("keeps checklist fallbacks bounded and independently mutable", () => {
    const fallback = normalizePrepChecklist(null);
    expect(fallback).toEqual(defaultPrepChecklist);
    fallback[0] = true;
    expect(defaultPrepChecklist).toEqual([false, false, false]);
    expect(normalizePrepChecklist([true, "yes", false, true])).toEqual([true, false, false]);
  });

  it("formats a concise descriptive doctor report", () => {
    const report = formatDoctorReport(entries, ["What should I track next?"]);
    expect(report).toContain("AI Health Journal — recent notes");
    expect(report).toContain("Appointment snapshot — last 14 days");
    expect(report).toContain("Logged days: 3 (21% of selected days)");
    expect(report).toContain("Notes recorded: 0 days");
    expect(report).toContain("Average reported activity: 0 minutes");
    expect(report).toContain("activity 0m");
    expect(report).toContain("Highest self-rated symptom severity: 3/5");
    expect(report).toContain("range 2–3/5");
    expect(report).toContain("Self-rated mood range: 2–3/5");
    expect(report).toContain("Self-reported sleep range: 5.0–7.0 hours");
    expect(report).toContain("Symptoms to review:");
    expect(report).toContain("Clinician review prompts:");
    expect(report).toContain(clinicianReviewChecklist[0]);
    expect(report).toContain("What, if anything, seemed to make it better or worse?");
    expect(report).toContain("How long did each episode or change last?");
    expect(report).toContain("Did your ability to do usual activities change?");
    expect(report).toContain("Questions to discuss:");
    expect(formatDoctorReport(entries, [], { onset: "Monday", duration: "2 days", triggers: "busy week", impact: "missed usual walk" })).toContain("Daily-life impact: missed usual walk");
    expect(formatDoctorReport(entries, [], { onset: "", duration: "", triggers: "", impact: "" }, 7)).toContain("Appointment snapshot — last 7 days");
    expect(normalizeClinicianReportFields({ mood: false, sleep: "no", symptoms: false })).toMatchObject({ mood: false, sleep: true, symptoms: false, activity: true, questions: true });
    const privateReport = formatDoctorReport(entries, ["Private question"], { onset: "Private onset", duration: "", triggers: "", impact: "" }, 14, { mood: false, sleep: false, activity: false, symptoms: false, noteStatus: false, questions: false, context: false });
    expect(privateReport).not.toContain("Private question");
    expect(privateReport).not.toContain("Private onset");
    expect(privateReport).not.toContain("Average self-rated mood");
    expect(clinicianReportHasContent([], [], { onset: "", duration: "", triggers: "", impact: "" }, { mood: false, sleep: false, activity: false, symptoms: false, noteStatus: false, questions: false, context: false })).toBe(false);
    expect(clinicianReportHasContent(entries, [], { onset: "", duration: "", triggers: "", impact: "" }, { mood: false, sleep: false, activity: false, symptoms: false, noteStatus: false, questions: false, context: false })).toBe(false);
    const conciseReport = formatDoctorReport(entries, ["Ask about sleep"], { onset: "", duration: "", triggers: "", impact: "" }, 14, { mood: true, sleep: true, activity: true, symptoms: true, noteStatus: true, questions: true, context: true }, "concise");
    expect(conciseReport).toContain("AI Health Journal — appointment summary");
    expect(conciseReport.indexOf("Appointment snapshot")).toBeLessThan(conciseReport.indexOf("Evidence details"));
    for (const language of ["en", "es", "fr", "zh", "de", "it", "pt", "ja", "ko", "ar", "hi", "ru", "tr", "nl"] as const) expect(translateMedicalReport(language, "concise").length).toBeGreaterThan(0);
    expect(report).toContain("not a diagnosis or treatment recommendation");
    expect(normalizeClinicianQuestions(["  first question  ", 42, "x".repeat(300), ...Array.from({ length: 12 }, (_, index) => `q${index}`)])).toHaveLength(10);
    expect(formatDoctorReport(entries, [" ", "  Discuss timing  "])).toContain("Discuss timing");
  });
  it("builds an evidence-linked appointment snapshot without clinical interpretation", () => {
    const snapshot = buildAppointmentSnapshot(entries, 2);
    expect(snapshot.daysLogged).toBe(2);
    expect(snapshot.coveragePercent).toBe(100);
    expect(snapshot.notesLogged).toBe(0);
    expect(snapshot.symptomDays).toBe(2);
    expect(snapshot.averageActivityMinutes).toBe(0);
    expect(snapshot.highestSelfRatedSeverity).toBe(3);
    expect(snapshot.moodRange).toEqual({ min: 2, max: 3 });
    expect(snapshot.averageMood).toBe(2.5);
    expect(snapshot.averageSleepHours).toBe(5.25);
    expect(snapshot.sleepRange).toEqual({ min: 5, max: 5.5 });
    expect(snapshot.symptoms[0]).toMatchObject({ name: "Fatigue", count: 2, averageSeverity: 2.5, minSeverity: 2, maxSeverity: 3 });
    expect(snapshot.symptoms[0].evidenceDates).toEqual(["2026-08-16", "2026-08-17"]);
    const mixedCaseEntries = [{ ...entries[0], symptoms: [{ name: "Fatigue", severity: 2 }] }, { ...entries[1], symptoms: [{ name: "fatigue", severity: 4 }] }];
    expect(buildAppointmentSnapshot(mixedCaseEntries, 2).symptoms[0]).toMatchObject({ name: "Fatigue", count: 2, averageSeverity: 3 });
    expect(buildClinicianQuestions(mixedCaseEntries, 14).join(" ")).toContain("fatigue on 2 days");
    const duplicateDayEntries = [{ ...entries[0], symptoms: [{ name: "Fatigue", severity: 2 }, { name: "fatigue", severity: 4 }] }];
    expect(buildAppointmentSnapshot(duplicateDayEntries, 1).symptoms[0]).toMatchObject({ count: 1, averageSeverity: 4, minSeverity: 4, maxSeverity: 4 });
    expect(buildClinicianQuestions(duplicateDayEntries, 14).join(" ")).toContain("fatigue on 1 day");
    expect(formatDoctorReport(entries, []).toLowerCase()).toContain("not a diagnosis");
  });

  it("creates grounded prompt and question variants", () => {
    const prompts = reflectionPrompts({ ...defaultPreferences, focus: "symptoms", cadence: "daily" }, entries);
    expect(prompts[0]).toContain("Fatigue");
    const questions = buildClinicianQuestions(entries, 14);
    expect(questions.join(" ")).toContain("fatigue");
    expect(questions.join(" ")).toContain("3 days");
    expect(questions.join(" ")).toContain("average self-rated severity 2.3/5");
  });

  it("normalizes language preferences and keeps translation fallback safe", () => {
    expect(normalizeLanguage("es")).toBe("es");
    expect(normalizeLanguage("fr")).toBe("fr");
    expect(normalizeLanguage("de")).toBe("de");
    expect(normalizeLanguage("zh")).toBe("zh");
    expect(normalizeLanguage("ja")).toBe("ja");
    expect(normalizeLanguage("ar")).toBe("ar");
    expect(normalizeLanguage("pt")).toBe("pt");
    expect(translate("es", "language")).toBe("Idioma");
    expect(translate("fr", "continuePrivately")).toContain("privé");
    expect(translate("es", "undoImport")).toContain("Deshacer");
    expect(translate("fr", "undoImport")).toContain("Annuler");
    expect(translate("zh", "undoImport")).toContain("撤销");
    expect(translate("zh", "continuePrivately")).toContain("隐私");
    expect(languageOptions()).toHaveLength(14);
    expect(translate("en", "premiumComingSoonBody")).toContain("does not charge");
    expect(translate("en", "undoImportBanner")).toContain("undone");
    expect(translate("de", "undoImport")).toContain("rückgängig");
    expect(translate("en", "premiumPrivacy")).toContain("local-first");
    expect(translate("de", "premiumTitle")).toBe(translate("en", "premiumTitle"));
    expect(translate("en", "premiumAnnual")).toBe("Annual");
    expect(translate("en", "premiumRestoreBody")).toContain("app-store billing");
    expect(translate("en", "premiumKeepFree")).toContain("free journal");
    expect(normalizePremiumEntitlement({ active: true, plan: "monthly", source: "app_store", checkedAt: "2026-08-18T00:00:00.000Z" })).toMatchObject({ active: true, plan: "monthly", source: "app_store" });
    expect(normalizePremiumEntitlement({ active: true, plan: "annual", source: "none" })).toEqual(defaultPremiumEntitlement);
    expect(normalizePremiumEntitlement({ active: "yes" })).toEqual(defaultPremiumEntitlement);
    expect(premiumProducts.map((product) => product.id)).toEqual(["journal_pro_monthly", "journal_pro_annual"]);
    expect(premiumProductForPlan("annual").billingPeriod).toBe("P1Y");
    expect(translate("en", "premiumReadinessBody")).toContain("without turning daily notes into a diagnosis");
    expect(translate("en", "premiumEarlyAccessRequested")).toContain("on this device");
    expect(translate("en", "premiumBillingSetupBody")).toContain("no purchase");
    expect(translate("en", "premiumDecisionBody")).toContain("free journal remains useful");
    expect(translate("en", "premiumDecisionBenefitTwo")).toContain("user-controlled evidence");
    expect(translate("en", "premiumPrivacyPromise")).toContain("never required");
    expect(translate("en", "premiumReminderBody")).toContain("does not send notifications");
    expect(normalizeRetentionPreference({ appointmentReminder: true, dismissed: "yes", appointmentDate: "2026-09-30" })).toEqual({ appointmentReminder: true, dismissed: false, appointmentDate: "2026-09-30" });
    expect(normalizeRetentionPreference({ appointmentDate: "not-a-date" }).appointmentDate).toBe(null);
    expect(isValidIsoDate("2026-09-30")).toBe(true);
    expect(isValidIsoDate("2026-02-30")).toBe(false);
    expect(isValidIsoDate("2026-9-3")).toBe(false);
    expect(daysUntilIsoDate("2026-09-30", "2026-09-18")).toBe(12);
    expect(daysUntilIsoDate("2026-09-18", "2026-09-18")).toBe(0);
    expect(daysUntilIsoDate("2026-09-10", "2026-09-18")).toBe(-8);
    expect(daysUntilIsoDate("not-a-date", "2026-09-18")).toBe(null);
    expect(normalizePrepChecklist([true, "yes", false, true])).toEqual([true, false, false]);
    expect(normalizePrepChecklist(null)).toEqual([false, false, false]);
    expect(translate("en", "premiumMockBillingBody")).toContain("does not charge");
    expect(normalizeRetentionPreference(null)).toEqual(defaultRetentionPreference);
  });

  it("selects analytics evidence without mutating journal entries", () => {
    const selected = selectAnalyticsEvidence(entries, ["2"]);
    expect(selected.map((entry) => entry.id)).toEqual(["2"]);
    expect(entries).toHaveLength(3);
    expect(selectAnalyticsEvidence(entries, [])).toEqual(entries);
  });

  it("formats accessible and clinician-ready analytics without diagnostic claims", () => {
    const series = analyticsSeries(entries, 7);
    expect(formatAnalyticsAccessibility(series, "en-US")).toContain("logged day");
    const summary = formatAnalyticsClinicianSummary(entries, 7, "de-DE");
    expect(summary).toContain("Source dates:");
    expect(summary).toContain("not a diagnosis");
    expect(summary).toContain("5,8");
  });

  it("shapes localized analytics series without inventing values", () => {
    const series = analyticsSeries(entries, 2);
    expect(series.map((point) => point.date)).toEqual(["2026-08-16", "2026-08-17"]);
    expect(series[0].sleep).toBe(5);
    expect(formatAnalyticsNumber(5.5, "en-US")).toBe("5.5");
    expect(formatAnalyticsNumber(5.5, "de-DE")).toBe("5,5");
    expect(formatAnalyticsDate("2026-08-17", "en-US")).toContain("17");
  });

  it("summarizes analytics coverage and week-over-week changes descriptively", () => {
    const coverage = analyticsCoverage(entries, 7);
    expect(coverage.daysLogged).toBe(3);
    expect(coverage.missingDays).toBe(4);
    expect(coverage.coveragePercent).toBe(43);
    expect(coverage.metricCoverage.notes).toBe(0);
    const comparison = weekOverWeekSummary(entries);
    expect(comparison.recentDays).toBe(3);
    expect(comparison.priorDays).toBe(0);
    expect(comparison.descriptiveOnly).toBe(true);
    expect(comparison.recentAverageMood).toBeCloseTo(8 / 3);
  });

  it("normalizes biometric cancellation and device failure messages safely", () => {
    expect(biometricFailureMessage("user_cancel")).toContain("cancelled");
    expect(biometricFailureMessage("not_available")).toContain("unavailable on this device");
    expect(biometricFailureMessage("not_enrolled")).toContain("Set up Face ID");
    expect(biometricFailureMessage("lockout")).toContain("temporarily locked");
    expect(biometricFailureMessage("unknown")).toContain("did not complete");
  });

  it("covers safe async failure messages used by loading and persistence fallbacks", () => {
    expect(userSafeErrorMessage(new Error("storage unavailable"), "Your current entries were kept.")).toBe("Your current entries were kept.");
    expect(userSafeErrorKind(new Error("No encrypted backup found"))).toBe("backup-missing");
    expect(userSafeErrorKind(new Error("Face ID native device error"))).toBe("device-security");
    expect(userSafeErrorKind(new Error("Invalid encrypted backup"))).toBe("invalid-data");
    expect(userSafeErrorKind(new Error("storage unavailable"))).toBe("unknown");
    expect(userSafeErrorKind("Invalid imported data")).toBe("invalid-data");
    expect(userSafeErrorMessage(new Error("Invalid encrypted backup"))).toContain("provided data could not be used");
  });

  it("normalizes user-facing errors and rejects malformed imports safely", () => {
    expect(userSafeErrorMessage(new Error("Invalid journal entries"))).toContain("provided data could not be used");
    expect(userSafeErrorMessage(new Error("storage unavailable"), "Try again later.")).toBe("Try again later.");
    expect(userSafeErrorMessage(new Error("Face ID native device error: secret-token"))).not.toContain("secret-token");
    expect(userSafeErrorMessage(new Error("No encrypted backup found for account 123"))).toBe("No encrypted backup is available on this device.");
    expect(() => parseJournalExport("not-json")).toThrow("Malformed journal export");
  });

  it("normalizes persisted drafts and positions evidence timeline points", () => {
    const source = [["one"], ["two"], ["three"], ["four"], [1]] as unknown[];
    const normalized = normalizeDraftHistory(source);
    expect(normalized).toEqual([["one"], ["two"], ["three"]]);
    const spaced = normalizeDraftHistory([["  question  ", "  note  "]]);
    expect(spaced).toEqual([["question", "note"]]);
    (source[0] as string[])[0] = "changed";
    expect(normalized[0]).toEqual(["one"]);
    expect(evidenceTimeline(["2026-08-18", "2026-08-16", "2026-08-18"])).toEqual([{ date: "2026-08-16", position: 0 }, { date: "2026-08-18", position: 100 }]);
  });

  it("retries analytics context hydration successfully after mocked storage recovery", async () => {
    const loader = vi.fn().mockResolvedValue([{ date: "2026-08-18", note: "Travel week" }]);
    const retry = createAnalyticsContextRetry(loader);
    await expect(retry()).resolves.toEqual({ status: "success", value: [{ date: "2026-08-18", note: "Travel week" }] });
    expect(loader).toHaveBeenCalledTimes(1);
  });

  it("surfaces mocked storage failure without throwing from analytics context retry", async () => {
    const failure = new Error("storage unavailable");
    const loader = vi.fn().mockRejectedValue(failure);
    const retry = createAnalyticsContextRetry(loader);
    await expect(retry()).resolves.toEqual({ status: "error", error: failure });
    expect(loader).toHaveBeenCalledTimes(1);
  });

  it("ignores repeated analytics context retry taps while storage is still loading", async () => {
    let resolveLoad: (value: AnalyticsContextAnnotation[]) => void = () => undefined;
    let loadCount = 0;
    const loader = vi.fn(() => { loadCount += 1; return loadCount === 1 ? new Promise<AnalyticsContextAnnotation[]>((resolve) => { resolveLoad = resolve; }) : Promise.resolve([]); });
    const retry = createAnalyticsContextRetry(loader);
    const first = retry();
    await Promise.resolve();
    await expect(retry()).resolves.toEqual({ status: "busy" });
    expect(loader).toHaveBeenCalledTimes(1);
    resolveLoad([]);
    await expect(first).resolves.toEqual({ status: "success", value: [] });
    await expect(retry()).resolves.toEqual({ status: "success", value: [] });
    expect(loader).toHaveBeenCalledTimes(2);
  });

  it("normalizes date-based context annotations and keeps invalid data out", () => {
    expect(normalizeAnalyticsContextAnnotations([
      { date: "2026-08-18", note: "  Travel week  " },
      { date: "not-a-date", note: "discard" },
      { date: "2026-08-18", note: "Updated context" },
      { date: "2026-08-17", note: "   " },
    ])).toEqual([{ date: "2026-08-18", note: "Updated context" }]);
    const largeContext = Array.from({ length: 400 }, (_, index) => ({ date: `2025-${String(Math.floor(index / 28) + 1).padStart(2, "0")}-${String((index % 28) + 1).padStart(2, "0")}`, note: `Context ${index}` }));
    expect(normalizeAnalyticsContextAnnotations(largeContext)).toHaveLength(365);
  });

  it("localizes audit warning actions across supported languages", () => {
    for (const language of languageOptions().map((option) => option.value)) {
      expect(translate(language, "auditWarningBody")).not.toBe("");
      expect(translate(language, "auditWarningRetry")).not.toBe("");
      expect(translate(language, "auditWarningDismiss")).not.toBe("");
      expect(translate(language, "auditWarningRetrying")).not.toBe("");
      expect(translate(language, "progressBackup")).not.toBe("");
      expect(translate(language, "progressRestore")).not.toBe("");
      expect(translate(language, "progressSave")).not.toBe("");
      expect(translate(language, "importingJournal")).not.toBe("");
      expect(translate(language, "clearingJournal")).not.toBe("");
      expect(translate(language, "completionImport")).not.toBe("");
      expect(translate(language, "completionClear")).not.toBe("");
      expect(translate(language, "importUndone")).not.toBe("");
      expect(translate(language, "undoExpiredTitle")).not.toBe("");
    }
    expect(translate("es", "auditWarningRetry")).toContain("Reintentar");
    expect(translate("fr", "auditWarningDismiss")).toContain("Fermer");
    expect(translate("zh", "auditWarningDismiss")).toContain("关闭");
  });

  it("supports concise and detailed clinician summaries with private context notes", () => {
    const concise = formatAnalyticsClinicianSummary(entries, 7, "en-US", { detail: "concise" });
    const detailed = formatAnalyticsClinicianSummary(entries, 7, "en-US", { detail: "detailed", contextNote: "Travel week" });
    expect(concise).not.toContain("Metric coverage:");
    expect(concise).not.toContain("Travel week");
    expect(detailed).toContain("Metric coverage:");
    expect(detailed).toContain("Most logged symptoms: Fatigue (3)");
    expect(detailed).toContain("Symptom evidence: Fatigue: average self-rated severity 2.3/5");
    expect(detailed).toContain("Aug 16");
    expect(detailed).toContain("User context notes: Travel week");
    expect(formatAnalyticsClinicianSummary(entries, 7, "en-US", { detail: "detailed", contextNotes: ["2026-08-18: Travel week"] })).toContain("2026-08-18: Travel week");
    expect(normalizeClinicianContextNotes(["  first  ", 42, "x".repeat(300), "second", "third", "fourth", "fifth", "sixth"])).toEqual(["first", "x".repeat(240), "second", "third", "fourth"]);
    expect(detailed.toLowerCase()).toContain("not a diagnosis");
  });

  it("formats selected analytics source previews without diagnostic interpretation", () => {
    const preview = formatAnalyticsSourcePreview([{ ...entries[0], notes: "Felt tired after work" }], "en-US", { symptoms: "Síntomas", mood: "Ánimo", sleep: "Sueño", note: "Nota", none: "Ninguno" });
    expect(preview).toContain("Aug 16");
    expect(preview).toContain("Síntomas: Fatigue (2/5)");
    expect(preview).toContain("Ánimo: 3/5");
    expect(preview).toContain("Sueño: 5h");
    expect(preview).toContain("Nota: Felt tired after work");
    expect(preview).toContain("Felt tired after work");
    const longPreview = formatAnalyticsSourcePreview([{ ...entries[0], notes: "x".repeat(300) }]);
    expect(longPreview).toContain(`${"x".repeat(240)}…`);
    expect(longPreview).not.toContain("x".repeat(241));
    expect(preview.toLowerCase()).not.toMatch(/diagnos|prescrib|treatment/);
  });

  it("keeps source selection deterministic for select-all and clear-all controls", () => {
    const selectAll = applyAnalyticsEvidenceSelection(entries, null);
    const clearAll = applyAnalyticsEvidenceSelection(entries, []);
    expect(selectAll.map((entry) => entry.id)).toEqual(["1", "2", "3"]);
    expect(clearAll).toEqual([]);
  });

  it("formats source previews and compares bounded drafts", () => {
    const preview = formatEvidenceSource(entries[0]);
    expect(preview.mood).toBe("Mood 3/5");
    expect(preview.symptoms).toContain("Fatigue");
    const history = rememberDraft([["older"]], ["current"], 2);
    expect(history).toEqual([["current"], ["older"]]);
  });

  it("keeps every AI output mode descriptive and non-diagnostic", () => {
    for (const promptStyle of ["concise", "reflective", "questions"] as const) {
      const promptText = reflectionPrompts({ ...defaultPreferences, promptStyle }, entries).join(" ").toLowerCase();
      expect(promptText).not.toContain("diagnos");
      expect(promptText).not.toContain("prescrib");
    }
    for (const questionStyle of ["concise", "exploratory", "structured"] as const) {
      const questionText = buildClinicianQuestions(entries, 14, questionStyle).join(" ").toLowerCase();
      expect(questionText).not.toContain("diagnos");
      expect(questionText).not.toContain("treatment");
    }
    expect(formatDoctorReport(entries, []).toLowerCase()).toContain("not a diagnosis");
  });

  it("normalizes backup status safely", () => {
    expect(normalizeBackupStatus(null)).toEqual({ savedAt: null, restoredAt: null });
    expect(normalizeBackupStatus({ savedAt: "2026-08-18T00:00:00.000Z" })).toEqual({ savedAt: "2026-08-18T00:00:00.000Z", restoredAt: null });
  });

  it("rejects invalid encrypted backup envelopes", async () => {
    await expect(restoreEncryptedBackup()).rejects.toThrow("Secure backups require a native device");
  });
});
