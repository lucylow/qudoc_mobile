/** @type {const} */
const themeColors = {
  primary: { light: '#2F6B62', dark: '#78B8AA' },
  background: { light: '#F7F8F5', dark: '#17212B' },
  surface: { light: '#FFFFFF', dark: '#23313A' },
  foreground: { light: '#17212B', dark: '#F7F8F5' },
  muted: { light: '#66727A', dark: '#B7C0C4' },
  border: { light: '#E2E7E3', dark: '#3B4B54' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
