# iOS Release Research

## Sources

- Expo app configuration: https://docs.expo.dev/versions/latest/config/app/
- Expo privacy manifests: https://docs.expo.dev/guides/apple-privacy/
- Apple privacy manifest files: https://developer.apple.com/documentation/bundleresources/privacy-manifest-files

## Key findings

Expo supports `ios.privacyManifests` in `app.config.ts` and generates `PrivacyInfo.xcprivacy` for iOS builds. Expo recommends declaring required-reason APIs used by the app or bundled dependencies and updating Expo SDK libraries to the latest compatible versions. Apple privacy manifests describe collected data and required-reason API usage; the manifest must be included in the app target. Expo app configuration also supports `description`, `version`, `ios.bundleIdentifier`, `ios.buildNumber`, and a recommended 1024x1024 app icon. Apple App Store submissions require required-reason API declarations where applicable.
