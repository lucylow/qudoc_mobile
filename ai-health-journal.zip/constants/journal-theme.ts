import type { TextStyle, ViewStyle } from "react-native";

export const journalTheme = {
  colors: {
    ink: "#17212B",
    muted: "#66727A",
    canvas: "#F7F8F5",
    surface: "#FFFFFF",
    border: "#E2E7E3",
    teal: "#2F6B62",
    tealDark: "#205047",
    mint: "#DCEDE7",
    sand: "#F2E8D8",
    warning: "#B8752A",
    danger: "#A94A4A",
  },
  spacing: { xs: 4, sm: 8, md: 12, base: 16, lg: 20, xl: 24, xxl: 32 },
  radii: { sm: 10, md: 14, lg: 18, xl: 22, pill: 999 },
  type: {
    screenTitle: { fontSize: 28, lineHeight: 33, fontWeight: "700" } as TextStyle,
    sectionTitle: { fontSize: 18, lineHeight: 23, fontWeight: "700" } as TextStyle,
    body: { fontSize: 15, lineHeight: 22 } as TextStyle,
    caption: { fontSize: 12, lineHeight: 17 } as TextStyle,
  },
  card: { borderRadius: 18, borderWidth: 1, borderColor: "#E2E7E3" } as ViewStyle,
} as const;
