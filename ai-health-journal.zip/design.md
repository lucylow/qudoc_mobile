# AI Health Journal — Mobile Interface Design

## Product direction

AI Health Journal is a calm, privacy-conscious companion for capturing daily health experiences and preparing for a healthcare visit. It does not diagnose, prescribe, or recommend treatment. Its value is helping users remember what happened, see simple personal trends, and turn their own notes into a concise discussion guide.

The experience is designed for portrait orientation and one-handed use. The primary action is always within comfortable thumb reach, copy is plain-language and non-alarmist, and every insight screen reinforces that the app is informational and not a substitute for professional care.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Today / Home | Greeting, current logging streak, a prominent “Log today” action, a short recent-entry preview, and a “Prepare for my visit” shortcut. |
| New entry | Date, symptom chips, severity control, mood, sleep, activity, medication note, and free-form notes. Save locally and provide confirmation. |
| History | Chronological FlatList of entries with date, top symptoms, mood, and sleep. Tap an item for detail. |
| Entry detail | Full entry summary, edit/delete actions, and a neutral “What to mention at your visit” prompt based only on the entry. |
| Trends | Simple personal charts or summary cards for symptom frequency, sleep, mood, and activity. Copy describes observations, not causes. |
| Insights | Safe pattern summaries such as “You logged lower mood on days with less sleep,” plus suggested questions for a clinician. No diagnosis or treatment language. |
| Doctor prep | Select a date range, review a structured timeline, add appointment notes, and export/share a visit-ready summary. |
| Premium | Clear value explanation for unlimited history, longitudinal trends, AI-assisted summaries, and export. Includes a non-blocking free-tier path. |
| Settings | Privacy explanation, local data controls, notification preferences, disclaimer, and account/sync placeholder only if later requested. |

## Key user flows

### Daily logging

1. User opens Today and sees the day’s prompt.
2. User taps “Log today.”
3. User selects symptoms, rates severity and mood, records sleep and activity, and optionally adds notes.
4. User taps “Save entry.”
5. The app confirms the entry was saved locally and returns to Today with the latest summary.

### Preparing for a doctor visit

1. User taps “Prepare for my visit.”
2. User chooses a date range, defaulting to the last 14 days.
3. The app builds a chronological timeline from saved entries.
4. The user reviews observed patterns and edits a list of questions.
5. The user exports or shares the summary as a plain-language visit guide.

### Reviewing a pattern

1. User opens Insights or Trends.
2. The app shows only patterns supported by the user’s logged data.
3. The app labels the content as an observation and includes “Discuss with your healthcare provider” where appropriate.
4. The user can turn a pattern into a question for their next appointment.

### Premium conversion

1. User reaches a value moment after building a useful history or starting doctor prep.
2. The app previews the benefit of unlimited history, longitudinal trends, and export.
3. User can choose a premium plan or continue with the free tier without losing access to their data.

## Color choices

The visual system uses a deep ink navy for trust, a warm paper background for calm journaling, and a restrained mint accent for progress and positive confirmation.

| Token | Color | Use |
|---|---|---|
| Background | `#F7F8F5` | Main canvas and reading surfaces |
| Surface | `#FFFFFF` | Cards, forms, and sheets |
| Foreground | `#17212B` | Primary text and headings |
| Muted | `#66727A` | Supporting copy and metadata |
| Primary | `#2F6B62` | Main actions, active states, and links |
| Primary dark | `#205047` | Pressed states and high-contrast labels |
| Mint tint | `#DCEDE7` | Insight backgrounds and progress accents |
| Sand tint | `#F2E8D8` | Gentle reminders and appointment-prep surfaces |
| Border | `#E2E7E3` | Dividers and card outlines |
| Warning | `#B8752A` | Non-alarmist attention states |
| Error | `#A94A4A` | Destructive actions only |

Typography follows iOS conventions: large semibold screen titles, readable 17-point body copy, generous line height, and compact metadata. Cards use soft 16–20px radii and subtle borders rather than heavy shadows.

## Safety and trust language

The app should say “observed pattern,” “your notes,” and “questions to discuss,” never “diagnosis,” “condition,” “treatment,” or “what you should take.” A persistent but quiet disclaimer appears on Insights and Doctor prep: “This is a summary of what you logged, not medical advice. Seek professional care for medical concerns.”
