from pathlib import Path
from PIL import Image

source = Path('/home/ubuntu/webdev-static-assets/ai-health-journal-icon.png')
targets = [
    Path('/home/ubuntu/ai-health-journal/assets/images/icon.png'),
    Path('/home/ubuntu/ai-health-journal/assets/images/splash-icon.png'),
    Path('/home/ubuntu/ai-health-journal/assets/images/favicon.png'),
    Path('/home/ubuntu/ai-health-journal/assets/images/android-icon-foreground.png'),
]
image = Image.open(source).convert('RGBA')
for target in targets:
    size = 512 if target.name != 'favicon.png' else 192
    image.resize((size, size), Image.Resampling.LANCZOS).save(target, format='PNG', optimize=True, compress_level=9)
