import { existsSync, readFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { resolve } from "node:path";

const root = process.cwd();
const requiredAssets = [
  "assets/images/icon.png",
  "assets/images/splash-icon.png",
  "assets/images/favicon.png",
  "assets/images/android-icon-foreground.png",
];
const failures = [];

function fail(message) { failures.push(message); }
function requireFile(relativePath) { if (!existsSync(resolve(root, relativePath))) fail(`Missing required file: ${relativePath}`); }

for (const asset of requiredAssets) requireFile(asset);
const configText = execFileSync("pnpm", ["exec", "expo", "config", "--json"], { cwd: root, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
const config = JSON.parse(configText);
const pkg = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8"));

if (!config.name || config.name.includes("{{")) fail("App name is missing or still contains a template placeholder.");
if (!config.slug || config.slug.includes("{{")) fail("App slug is missing or still contains a template placeholder.");
if (!config.description) fail("App description is missing.");
if (!/^\d+\.\d+\.\d+$/.test(config.version ?? "")) fail(`Invalid app version: ${config.version}`);
if (!/^[a-z][a-z0-9+.-]*$/.test(config.scheme ?? "")) fail(`Invalid URL scheme: ${config.scheme}`);
if (!config.ios?.bundleIdentifier || config.ios.bundleIdentifier.includes("{{")) fail("iOS bundle identifier is missing or templated.");
if (!/^\d+$/.test(String(config.ios?.buildNumber ?? ""))) fail("iOS buildNumber must be a numeric string.");
if (!config.ios?.privacyManifests) fail("iOS privacyManifests configuration is missing.");
if (config.ios.privacyManifests.NSPrivacyTracking !== false) fail("NSPrivacyTracking must be false for this local-first app.");
if (!Array.isArray(config.ios.privacyManifests.NSPrivacyCollectedDataTypes)) fail("NSPrivacyCollectedDataTypes must be an array.");
if (!Array.isArray(config.ios.privacyManifests.NSPrivacyAccessedAPITypes)) fail("NSPrivacyAccessedAPITypes must be an array.");
if (pkg.dependencies?.expo !== "~54.0.37") fail(`Unexpected Expo SDK dependency: ${pkg.dependencies?.expo}`);

if (failures.length) {
  console.error("Release check failed:");
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}
console.log(`Release check passed for ${config.name} ${config.version} (${config.ios.bundleIdentifier}, build ${config.ios.buildNumber}).`);
console.log(`Verified ${requiredAssets.length} required assets, iOS privacy-manifest configuration, and Expo SDK ${pkg.dependencies.expo}.`);
