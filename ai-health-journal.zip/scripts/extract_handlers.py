from pathlib import Path

source = Path('app/(tabs)/index.tsx').read_text()
keys = ['shareExportSafely', 'shareAnalytics', 'copyAnalytics', 'retryNoticeTimingHydration', 'toggleBiometricLock', 'deleteEntry', 'saveInterest', 'selectPlan', 'saveLanguageSafely', 'savePreferencesSafely', 'clearSafely', 'resetOnboardingSafely', 'toggleChecklist', 'updateChecklistLabel', 'resetChecklist', 'retryContextHydration', 'confirmShareAnalytics', 'saveContextAnnotation', 'deleteContextAnnotation']
for key in keys:
    marker = f'const {key} = async'
    start = source.find(marker)
    if start < 0:
        print(f'\n## {key}: missing')
        continue
    end = source.find('const ', start + len(marker))
    if end < 0:
        end = min(len(source), start + 7000)
    print(f'\n## {key}\n{source[start:end][:7000]}')
