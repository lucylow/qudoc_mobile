# AI Health Journal — Expo and iOS App Store Release Guide

## Current release configuration

The project is configured as a portrait Expo SDK 54 application named **AI Health Journal** with iOS bundle identifier `com.app.aihealthjournal`, app version `1.0.0`, and initial iOS build number `1`. The app declares a local-first privacy posture in `app.config.ts`: tracking is disabled, collected-data types are empty, and required-reason API declarations are explicitly present for the generated iOS privacy manifest.

Run the local release gate before creating a build:

```bash
pnpm release:check
pnpm test
pnpm check
pnpm lint
```

The release gate verifies the resolved Expo config, bundle identity, version format, numeric iOS build number, privacy-manifest shape, Expo SDK version, and required icon/splash assets.

## EAS build workflow

The repository includes `eas.json` profiles for development, internal preview, and production builds. In the project UI, use the **Publish** action after reviewing the latest checkpoint. The production profile is intended for the iOS App Store/TestFlight build; the development and preview profiles are for device testing and internal distribution.

Before the first production build, sign in to an Expo account with EAS access and connect the Apple Developer account when prompted. Confirm the Apple Team, Bundle ID, distribution certificate, and provisioning profile belong to the intended organization. Keep the bundle identifier stable after the first App Store submission.

## Apple App Store Connect steps

Create the app record in App Store Connect using the exact bundle identifier `com.app.aihealthjournal`. Add the app name, subtitle, description, keywords, support URL, marketing URL if applicable, age rating, category, screenshots, app icon, and privacy-policy URL. Upload the production build to TestFlight, test on a physical iPhone and an iPad if tablet support remains enabled, and complete internal testing before requesting external review.

The product is a private local-first journal. The App Store privacy answers must accurately reflect the final shipped binary and any third-party SDK behavior. The current app does not automatically send journal content, does not use tracking, and does not provide diagnosis or treatment recommendations. Re-check these answers if future releases add analytics, accounts, cloud sync, advertising, or external AI processing.

## Health and safety review

Keep App Store copy clear that the journal supports personal observation and appointment preparation rather than diagnosis, triage, prescribing, or emergency care. Include a visible disclaimer that urgent symptoms require appropriate emergency or professional care. Verify every exported report is user-reviewed before sharing and that raw note text remains excluded unless the user explicitly edits it into the report.

## Final submission checklist

- [ ] Run `pnpm release:check` successfully.
- [ ] Run tests, TypeScript validation, and lint successfully.
- [ ] Test onboarding, journaling, Doctor Prep, report review, sharing/copying, local backup/restore, biometric lock, language selection, and clear-data flows on a physical iPhone.
- [ ] Confirm the privacy policy URL is publicly reachable and matches the shipped data practices.
- [ ] Create or verify the App Store Connect app record for the stable bundle identifier.
- [ ] Build production with the project UI Publish flow and upload to TestFlight.
- [ ] Complete App Store privacy nutrition labels and age-rating questionnaire accurately.
- [ ] Review screenshots and metadata for non-diagnostic, non-deceptive claims.
- [ ] Submit for Apple review only after TestFlight validation and store metadata review.

> Publishing and App Store submission require the developer’s Expo and Apple accounts, signing credentials, store metadata, screenshots, and privacy-policy URL. Those account actions must be completed by the owner in the project and App Store Connect interfaces.
