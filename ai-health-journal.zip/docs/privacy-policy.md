# AI Health Journal Privacy Policy

**Effective date:** August 21, 2026

AI Health Journal is a local-first journaling tool for recording personal observations and preparing questions for healthcare appointments. The app is not a medical device and does not diagnose, prescribe, triage, or replace professional care.

## Information stored on your device

Journal entries, optional appointment context, saved questions, preferences, local backups, and app activity history are stored on your device using local app storage. The app is designed not to transmit journal content to the developer automatically. Biometric protection, when enabled, uses the device’s authentication system; the app does not receive or store your biometric data.

## Sharing and exports

The app creates reports or exports only after you initiate the action. Before sharing a clinician report, the app shows the selected evidence window and included categories. You can exclude optional categories and clinician context. The operating system’s share sheet or clipboard destination receives the content you choose to share. That destination may have its own privacy practices.

## Health information

Because journal entries may contain health-related information, keep your device, operating-system account, backups, and chosen sharing destinations secure. Do not use the app for emergencies. Seek appropriate urgent or professional care for urgent concerns.

## Tracking and advertising

The app does not use advertising tracking and does not sell journal content. If a future version adds accounts, cloud synchronization, analytics, advertising, or external AI processing, this policy and the App Store privacy disclosures will be updated before those features are enabled.

## Deletion and retention

You can review and delete individual entries or clear local journal data from the app. Deleting app data or uninstalling the app may remove locally stored content according to your device’s operating-system behavior. Keep an encrypted local backup only where you understand the security of that destination.

## Contact

Before App Store submission, replace this section with the publisher’s support email or support webpage and host this policy at a stable public HTTPS URL. The policy URL entered in App Store Connect must remain reachable and match the behavior of the submitted build.
